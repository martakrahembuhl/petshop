<?php
/**
 * Script temporário para criar/resetar o usuário admin.
 * APAGUE este arquivo após usar!
 */

require_once __DIR__ . '/config/database.php';

$email = 'admin@patinhasecia.com';
$senha = 'admin123';
$hash  = password_hash($senha, PASSWORD_BCRYPT);

$pdo = getDB();

// Remove admin antigo se existir e recria com hash correto
$pdo->prepare("DELETE FROM usuarios WHERE email = ?")->execute([$email]);

$stmt = $pdo->prepare(
    "INSERT INTO usuarios (nome, telefone, email, senha_hash, perfil)
     VALUES ('Administrador', '(00) 00000-0000', ?, ?, 'admin')"
);
$stmt->execute([$email, $hash]);

echo "<h2>✅ Admin criado com sucesso!</h2>";
echo "<p>Email: <strong>{$email}</strong></p>";
echo "<p>Senha: <strong>{$senha}</strong></p>";
echo "<p>Hash gerado: <code>{$hash}</code></p>";
echo "<br><p style='color:red'><strong>⚠️ APAGUE este arquivo agora!</strong></p>";
echo "<p><a href='/petshop/admin/login.php'>Ir para o login →</a></p>";

