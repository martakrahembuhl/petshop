<?php
/**
 * Cancela um agendamento (somente admin).
 * GET /admin/cancelar.php?id=X&data=YYYY-MM-DD
 */

require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';

requireAdmin();

$id   = (int)($_GET['id']   ?? 0);
$data = $_GET['data'] ?? date('Y-m-d');

if ($id <= 0) {
    header('Location: /petshop/admin/dashboard.php?msg=erro&data=' . urlencode($data));
    exit;
}

$pdo  = getDB();
$stmt = $pdo->prepare(
    "UPDATE agendamentos SET status = 'cancelado' WHERE id = ? AND status = 'agendado'"
);
$stmt->execute([$id]);

if ($stmt->rowCount() > 0) {
    header('Location: /petshop/admin/dashboard.php?msg=cancelado&data=' . urlencode($data));
} else {
    header('Location: /petshop/admin/dashboard.php?msg=erro&data=' . urlencode($data));
}
exit;

