<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/duracao.php';

requireAdmin();

$pdo = getDB();

$dataSelecionada = $_GET['data'] ?? date('Y-m-d');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dataSelecionada)) {
    $dataSelecionada = date('Y-m-d');
}

// Agendamentos do dia
$stmt = $pdo->prepare(
    "SELECT a.id, a.data_hora_inicio, a.data_hora_fim, a.duracao_min, a.status,
            a.metodo_pagamento, a.transporte, a.taxa_transporte, a.valor_servico, a.valor_total,
            u.nome AS cliente_nome, u.telefone AS cliente_telefone,
            p.nome AS pet_nome, p.porte AS pet_porte,
            s.nome AS servico_nome
     FROM agendamentos a
     JOIN usuarios u ON u.id = a.usuario_id
     JOIN pets     p ON p.id = a.pet_id
     JOIN servicos s ON s.id = a.servico_id
     WHERE DATE(a.data_hora_inicio) = :data
     ORDER BY a.data_hora_inicio ASC"
);
$stmt->execute([':data' => $dataSelecionada]);
$agendamentos = $stmt->fetchAll();

// Dados para o calendário mensal (mês da data selecionada)
$mesAtual  = date('Y-m', strtotime($dataSelecionada));
$stmtCal   = $pdo->prepare(
    "SELECT DATE(data_hora_inicio) AS dia, COUNT(*) AS total
     FROM agendamentos
     WHERE DATE_FORMAT(data_hora_inicio, '%Y-%m') = :mes
       AND status = 'agendado'
     GROUP BY dia"
);
$stmtCal->execute([':mes' => $mesAtual]);
$diasComAgendamento = [];
foreach ($stmtCal->fetchAll() as $row) {
    $diasComAgendamento[$row['dia']] = (int)$row['total'];
}

// Contadores
$totalDia      = count($agendamentos);
$agendadosDia  = count(array_filter($agendamentos, fn($a) => $a['status'] === 'agendado'));
$canceladosDia = count(array_filter($agendamentos, fn($a) => $a['status'] === 'cancelado'));
$receitaDia    = array_sum(array_map(fn($a) => $a['status'] === 'agendado' ? $a['valor_total'] : 0, $agendamentos));

$portesLabel = ['pequeno' => 'Pequeno', 'medio' => 'Médio', 'grande' => 'Grande'];
$pagtoLabel  = ['dinheiro' => '💵 Dinheiro', 'debito' => '💳 Débito', 'credito' => '💳 Crédito', 'pix' => '💚 PIX'];
$transpLabel = ['proprio' => '🚗 Próprio', 'taxipet' => '🚕 TaxiPet'];
$statusLabel = [
    'agendado'  => '<span class="badge badge-agendado">Agendado</span>',
    'cancelado' => '<span class="badge badge-cancelado">Cancelado</span>',
    'concluido' => '<span class="badge badge-concluido">Concluído</span>',
];

$msg = $_GET['msg'] ?? '';
$msgTextos = [
    'cancelado' => ['tipo' => 'sucesso', 'texto' => 'Agendamento cancelado.'],
    'remarcado' => ['tipo' => 'sucesso', 'texto' => 'Agendamento remarcado.'],
    'erro'      => ['tipo' => 'erro',    'texto' => 'Ocorreu um erro. Tente novamente.'],
];

// Calendário: primeiro e último dia do mês
$primeiroDiaMes = date('Y-m-01', strtotime($dataSelecionada));
$ultimoDiaMes   = date('Y-m-t',  strtotime($dataSelecionada));
$diaSemanaInicio = (int)date('w', strtotime($primeiroDiaMes)); // 0=Dom
$totalDiasMes    = (int)date('t', strtotime($dataSelecionada));
$mesNome = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho',
            'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
$nomeMes = $mesNome[(int)date('n', strtotime($dataSelecionada)) - 1];
$anoMes  = date('Y', strtotime($dataSelecionada));

// Mês anterior e próximo para navegação
$mesAnterior = date('Y-m-d', strtotime($primeiroDiaMes . ' -1 month'));
$proximoMes  = date('Y-m-d', strtotime($primeiroDiaMes . ' +1 month'));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard — Patinhas & Cia Admin</title>
    <link rel="stylesheet" href="/petshop/assets/css/style.css">
    <link rel="stylesheet" href="/petshop/assets/css/admin.css">
</head>
<body class="app-page app-admin">

<header class="app-header admin-header">
    <div class="header-inner">
        <span class="logo-icon">🐾</span>
        <span class="header-title">Patinhas & Cia <em>Admin</em></span>
        <nav class="header-nav">
            <a href="/petshop/admin/configuracoes.php" class="btn btn-outline btn-sm">⚙️ Config</a>
            <span>Olá, <?= htmlspecialchars($_SESSION['nome']) ?></span>
            <a href="/petshop/admin/logout.php" class="btn btn-outline btn-sm">Sair</a>
        </nav>
    </div>
</header>

<main class="app-main">
    <div class="container container-wide">

        <?php if ($msg && isset($msgTextos[$msg])): ?>
        <div class="alert alert-<?= $msgTextos[$msg]['tipo'] ?>"><?= $msgTextos[$msg]['texto'] ?></div>
        <?php endif; ?>

        <div class="dashboard-layout">

            <!-- ── Coluna esquerda: Calendário ───────────────────────────── -->
            <aside class="dash-sidebar">
                <div class="card">
                    <div class="cal-nav">
                        <a href="?data=<?= $mesAnterior ?>" class="btn btn-sm btn-outline">‹</a>
                        <strong><?= $nomeMes ?> <?= $anoMes ?></strong>
                        <a href="?data=<?= $proximoMes ?>" class="btn btn-sm btn-outline">›</a>
                    </div>

                    <div class="calendario">
                        <!-- Cabeçalho dias da semana -->
                        <?php foreach (['D','S','T','Q','Q','S','S'] as $d): ?>
                        <div class="cal-head"><?= $d ?></div>
                        <?php endforeach; ?>

                        <!-- Células vazias antes do dia 1 -->
                        <?php for ($i = 0; $i < $diaSemanaInicio; $i++): ?>
                        <div class="cal-cell cal-vazio"></div>
                        <?php endfor; ?>

                        <!-- Dias do mês -->
                        <?php for ($dia = 1; $dia <= $totalDiasMes; $dia++):
                            $dataCell = date('Y-m', strtotime($dataSelecionada)) . '-' . str_pad($dia, 2, '0', STR_PAD_LEFT);
                            $qtd      = $diasComAgendamento[$dataCell] ?? 0;
                            $isHoje   = $dataCell === date('Y-m-d');
                            $isSel    = $dataCell === $dataSelecionada;
                            $classes  = 'cal-cell';
                            if ($isSel)  $classes .= ' cal-selecionado';
                            elseif ($isHoje) $classes .= ' cal-hoje';
                            if ($qtd > 0) $classes .= ' cal-tem-agend';
                        ?>
                        <a href="?data=<?= $dataCell ?>" class="<?= $classes ?>">
                            <span class="cal-dia"><?= $dia ?></span>
                            <?php if ($qtd > 0): ?>
                            <span class="cal-badge"><?= $qtd ?></span>
                            <?php endif; ?>
                        </a>
                        <?php endfor; ?>
                    </div>

                    <!-- Legenda -->
                    <div class="cal-legenda">
                        <span class="cal-leg-item"><span class="cal-leg-dot dot-hoje"></span> Hoje</span>
                        <span class="cal-leg-item"><span class="cal-leg-dot dot-agend"></span> Com agendamentos</span>
                    </div>
                </div>

                <!-- Seletor de data manual -->
                <div class="card" style="margin-top:0">
                    <form method="GET">
                        <div class="campo">
                            <label for="data-input">Ir para data:</label>
                            <input type="date" id="data-input" name="data"
                                   value="<?= $dataSelecionada ?>"
                                   onchange="this.form.submit()">
                        </div>
                    </form>
                </div>
            </aside>

            <!-- ── Coluna direita: Agenda do dia ─────────────────────────── -->
            <div class="dash-main">

                <!-- Stats -->
                <div class="stats-row">
                    <div class="stat-card">
                        <span class="stat-num"><?= $totalDia ?></span>
                        <span class="stat-label">Total</span>
                    </div>
                    <div class="stat-card stat-agendado">
                        <span class="stat-num"><?= $agendadosDia ?></span>
                        <span class="stat-label">Agendados</span>
                    </div>
                    <div class="stat-card stat-cancelado">
                        <span class="stat-num"><?= $canceladosDia ?></span>
                        <span class="stat-label">Cancelados</span>
                    </div>
                    <div class="stat-card stat-receita">
                        <span class="stat-num">R$ <?= number_format($receitaDia, 2, ',', '.') ?></span>
                        <span class="stat-label">Receita do dia</span>
                    </div>
                </div>

                <!-- Tabela de agendamentos -->
                <div class="card">
                    <h2 class="card-title">
                        Agenda — <?= date('d/m/Y', strtotime($dataSelecionada)) ?>
                        <?php if ($dataSelecionada === date('Y-m-d')): ?>
                        <span class="badge badge-hoje">Hoje</span>
                        <?php endif; ?>
                    </h2>

                    <?php if (empty($agendamentos)): ?>
                    <p class="hint">Nenhum agendamento para esta data.</p>
                    <?php else: ?>

                    <div class="table-wrapper">
                        <table class="tabela tabela-admin">
                            <thead>
                                <tr>
                                    <th>Início</th>
                                    <th>Término</th>
                                    <th>Cliente</th>
                                    <th>Tel.</th>
                                    <th>Pet</th>
                                    <th>Serviço</th>
                                    <th>Transporte</th>
                                    <th>Pagamento</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($agendamentos as $ag): ?>
                                <tr class="row-status-<?= $ag['status'] ?>">
                                    <td><strong><?= date('H:i', strtotime($ag['data_hora_inicio'])) ?></strong></td>
                                    <td><?= date('H:i', strtotime($ag['data_hora_fim'])) ?></td>
                                    <td><?= htmlspecialchars($ag['cliente_nome']) ?></td>
                                    <td><?= htmlspecialchars($ag['cliente_telefone']) ?></td>
                                    <td>
                                        <?= htmlspecialchars($ag['pet_nome']) ?>
                                        <small class="hint"><?= $portesLabel[$ag['pet_porte']] ?></small>
                                    </td>
                                    <td><?= htmlspecialchars($ag['servico_nome']) ?></td>
                                    <td><?= $transpLabel[$ag['transporte']] ?? '—' ?></td>
                                    <td><?= $pagtoLabel[$ag['metodo_pagamento']] ?? '—' ?></td>
                                    <td><strong>R$ <?= number_format($ag['valor_total'], 2, ',', '.') ?></strong></td>
                                    <td><?= $statusLabel[$ag['status']] ?></td>
                                    <td class="acoes">
                                        <?php if ($ag['status'] === 'agendado'): ?>
                                        <a href="/petshop/admin/remarcar.php?id=<?= $ag['id'] ?>&data=<?= $dataSelecionada ?>"
                                           class="btn btn-sm btn-outline">📅 Remarcar</a>
                                        <button type="button" class="btn btn-sm btn-danger"
                                                onclick="confirmarCancelamento(<?= $ag['id'] ?>, '<?= date('H:i', strtotime($ag['data_hora_inicio'])) ?>', '<?= htmlspecialchars(addslashes($ag['cliente_nome'])) ?>')">
                                            ✕ Cancelar
                                        </button>
                                        <?php else: ?>
                                        <span class="hint">—</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Linha do tempo -->
                <?php $ativos = array_filter($agendamentos, fn($a) => $a['status'] === 'agendado'); ?>
                <?php if (!empty($ativos)): ?>
                <div class="card">
                    <h2 class="card-title">Linha do Tempo</h2>
                    <div class="timeline">
                        <?php foreach ($ativos as $ag): ?>
                        <div class="timeline-item">
                            <div class="timeline-hora">
                                <span class="timeline-hora-range">
                                    <?= date('H:i', strtotime($ag['data_hora_inicio'])) ?>
                                    <span class="timeline-sep">→</span>
                                    <?= date('H:i', strtotime($ag['data_hora_fim'])) ?>
                                </span>
                                <span class="hint"><?= $ag['duracao_min'] ?> min</span>
                            </div>
                            <div class="timeline-info">
                                <strong><?= htmlspecialchars($ag['cliente_nome']) ?></strong>
                                <span class="detalhe">
                                    <?= htmlspecialchars($ag['pet_nome']) ?>
                                    &middot; <?= htmlspecialchars($ag['servico_nome']) ?>
                                    &middot; <?= $transpLabel[$ag['transporte']] ?? '' ?>
                                </span>
                            </div>
                            <div class="timeline-valor">
                                R$ <?= number_format($ag['valor_total'], 2, ',', '.') ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

            </div><!-- /dash-main -->
        </div><!-- /dashboard-layout -->

    </div>
</main>

<!-- Modal cancelamento -->
<div id="modal-cancelar" class="modal" style="display:none" role="dialog" aria-modal="true">
    <div class="modal-overlay" onclick="fecharModal()"></div>
    <div class="modal-box">
        <h3>Confirmar Cancelamento</h3>
        <p id="modal-texto"></p>
        <div class="modal-acoes">
            <button type="button" class="btn btn-outline" onclick="fecharModal()">Voltar</button>
            <a id="modal-confirmar" href="#" class="btn btn-danger">Sim, cancelar</a>
        </div>
    </div>
</div>

<script>
function confirmarCancelamento(id, hora, cliente) {
    document.getElementById('modal-texto').textContent =
        'Cancelar o agendamento das ' + hora + ' de ' + cliente + '?';
    document.getElementById('modal-confirmar').href =
        '/petshop/admin/cancelar.php?id=' + id + '&data=<?= $dataSelecionada ?>';
    document.getElementById('modal-cancelar').style.display = 'flex';
}
function fecharModal() {
    document.getElementById('modal-cancelar').style.display = 'none';
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') fecharModal(); });
</script>
</body>
</html>

