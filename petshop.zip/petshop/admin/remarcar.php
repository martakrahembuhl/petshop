<?php
/**
 * Tela de remarcação de agendamento (somente admin).
 * GET  /admin/remarcar.php?id=X&data=YYYY-MM-DD  → exibe formulário
 * POST /admin/remarcar.php                        → salva nova data/hora
 */

require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/duracao.php';

requireAdmin();

$pdo = getDB();

// ── Carrega o agendamento ─────────────────────────────────────────────────────
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
if ($id <= 0) {
    header('Location: /petshop/admin/dashboard.php?msg=erro');
    exit;
}

$stmt = $pdo->prepare(
    "SELECT a.*, u.nome AS cliente_nome, p.nome AS pet_nome, p.porte,
            s.nome AS servico_nome, s.tempo_base_min
     FROM agendamentos a
     JOIN usuarios u ON u.id = a.usuario_id
     JOIN pets     p ON p.id = a.pet_id
     JOIN servicos s ON s.id = a.servico_id
     WHERE a.id = ? AND a.status = 'agendado'"
);
$stmt->execute([$id]);
$ag = $stmt->fetch();

if (!$ag) {
    header('Location: /petshop/admin/dashboard.php?msg=erro');
    exit;
}

$dataOriginal = date('Y-m-d', strtotime($ag['data_hora_inicio']));
$erro = '';

// ── Processamento do POST ─────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $novaData    = $_POST['nova_data']    ?? '';
    $novoHorario = $_POST['novo_horario'] ?? '';

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $novaData) || !preg_match('/^\d{2}:\d{2}$/', $novoHorario)) {
        $erro = 'Selecione uma data e um horário válidos.';
    } else {
        $duracaoMin = calcularDuracao((int)$ag['tempo_base_min'], $ag['porte']);
        $novoInicio = new DateTime("{$novaData} {$novoHorario}:00");
        $novoFim    = clone $novoInicio;
        $novoFim->modify("+{$duracaoMin} minutes");

        // Verifica conflito ignorando o próprio agendamento
        $stmt = $pdo->prepare(
            "SELECT COUNT(*) FROM agendamentos
             WHERE status = 'agendado'
               AND id != :id
               AND data_hora_inicio < :fim
               AND data_hora_fim    > :inicio"
        );
        $stmt->execute([
            ':id'     => $id,
            ':inicio' => $novoInicio->format('Y-m-d H:i:s'),
            ':fim'    => $novoFim->format('Y-m-d H:i:s'),
        ]);

        if ((int)$stmt->fetchColumn() > 0) {
            $erro = 'Conflito de horário. Escolha outro horário.';
        } else {
            $stmt = $pdo->prepare(
                "UPDATE agendamentos
                 SET data_hora_inicio = ?, data_hora_fim = ?, duracao_min = ?
                 WHERE id = ?"
            );
            $stmt->execute([
                $novoInicio->format('Y-m-d H:i:s'),
                $novoFim->format('Y-m-d H:i:s'),
                $duracaoMin,
                $id,
            ]);
            header('Location: /petshop/admin/dashboard.php?msg=remarcado&data=' . urlencode($novaData));
            exit;
        }
    }
}

// Busca serviços para o select
$servicos = $pdo->query('SELECT id, nome, tempo_base_min FROM servicos WHERE ativo = 1')->fetchAll();
$portesLabel = ['pequeno' => 'Pequeno', 'medio' => 'Médio', 'grande' => 'Grande'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Remarcar — Patinhas & Cia Admin</title>
    <link rel="stylesheet" href="/petshop/assets/css/style.css">
</head>
<body class="app-page app-admin">

<header class="app-header admin-header">
    <div class="header-inner">
        <span class="logo-icon">🐾</span>
        <span class="header-title">Patinhas & Cia <em>Admin</em></span>
        <nav class="header-nav">
            <a href="/petshop/admin/dashboard.php?data=<?= urlencode($dataOriginal) ?>"
               class="btn btn-outline btn-sm">← Voltar</a>
            <a href="/petshop/admin/logout.php" class="btn btn-outline btn-sm">Sair</a>
        </nav>
    </div>
</header>

<main class="app-main">
    <div class="container">
        <section class="card">
            <h2 class="card-title">Remarcar Agendamento</h2>

            <!-- Resumo do agendamento atual -->
            <div class="info-box">
                <p><strong>Cliente:</strong> <?= htmlspecialchars($ag['cliente_nome']) ?></p>
                <p><strong>Pet:</strong> <?= htmlspecialchars($ag['pet_nome']) ?>
                   (<?= $portesLabel[$ag['porte']] ?>)</p>
                <p><strong>Serviço:</strong> <?= htmlspecialchars($ag['servico_nome']) ?></p>
                <p><strong>Horário atual:</strong>
                   <?= date('d/m/Y H:i', strtotime($ag['data_hora_inicio'])) ?>
                   até <?= date('H:i', strtotime($ag['data_hora_fim'])) ?>
                   (<?= $ag['duracao_min'] ?> min)
                </p>
            </div>

            <?php if ($erro): ?>
                <div class="alert alert-erro"><?= htmlspecialchars($erro) ?></div>
            <?php endif; ?>

            <form method="POST" id="form-remarcar" novalidate>
                <input type="hidden" name="id" value="<?= $id ?>">

                <div class="campo">
                    <label for="nova_data">Nova data</label>
                    <input type="date" id="nova_data" name="nova_data" required
                           min="<?= date('Y-m-d') ?>"
                           value="<?= htmlspecialchars($_POST['nova_data'] ?? '') ?>">
                </div>

                <div class="campo">
                    <label>Novo horário</label>
                    <div id="horarios-container-admin">
                        <p class="hint">Selecione uma data para ver os horários disponíveis.</p>
                    </div>
                    <input type="hidden" id="novo_horario" name="novo_horario"
                           value="<?= htmlspecialchars($_POST['novo_horario'] ?? '') ?>">
                </div>

                <div id="duracao-info-admin" class="duracao-badge" style="display:none">
                    ⏱ Duração: <strong id="duracao-valor-admin">—</strong>
                </div>

                <div class="form-acoes">
                    <a href="/petshop/admin/dashboard.php?data=<?= urlencode($dataOriginal) ?>"
                       class="btn btn-outline">Cancelar</a>
                    <button type="submit" class="btn btn-primary" id="btn-remarcar" disabled>
                        Confirmar Remarcação
                    </button>
                </div>
            </form>
        </section>
    </div>
</main>

<script>
(function () {
    const inputData    = document.getElementById('nova_data');
    const horariosBox  = document.getElementById('horarios-container-admin');
    const inputHorario = document.getElementById('novo_horario');
    const btnRemarcar  = document.getElementById('btn-remarcar');
    const duracaoInfo  = document.getElementById('duracao-info-admin');
    const duracaoValor = document.getElementById('duracao-valor-admin');

    // Dados do agendamento atual (passados pelo PHP)
    const servicoId    = <?= (int)$ag['servico_id'] ?>;
    const porte        = '<?= $ag['porte'] ?>';
    const agendamentoId = <?= $id ?>;

    let horarioSelecionado = '<?= htmlspecialchars($_POST['novo_horario'] ?? '') ?>';
    if (horarioSelecionado) {
        inputHorario.value = horarioSelecionado;
        btnRemarcar.disabled = false;
    }

    function buscarHorarios() {
        const data = inputData.value;
        if (!data) return;

        horariosBox.innerHTML = '<p class="hint carregando">Buscando horários…</p>';
        inputHorario.value = '';
        horarioSelecionado = null;
        btnRemarcar.disabled = true;

        const url = '/petshop/api/horarios_disponiveis.php'
            + '?data='           + encodeURIComponent(data)
            + '&servico_id='     + encodeURIComponent(servicoId)
            + '&porte='          + encodeURIComponent(porte)
            + '&agendamento_id=' + encodeURIComponent(agendamentoId);

        fetch(url)
            .then(r => r.json())
            .then(dados => {
                if (dados.erro) {
                    horariosBox.innerHTML = '<p class="hint hint-erro">' + dados.erro + '</p>';
                    return;
                }

                duracaoValor.textContent = dados.duracao_min + ' minutos';
                duracaoInfo.style.display = 'flex';

                if (!dados.horarios.length) {
                    horariosBox.innerHTML = '<p class="hint hint-erro">Nenhum horário disponível nesta data.</p>';
                    return;
                }

                const grid = document.createElement('div');
                grid.className = 'horarios-grid';

                dados.horarios.forEach(h => {
                    const btn = document.createElement('button');
                    btn.type = 'button';
                    btn.className = 'btn-horario';
                    btn.textContent = h;

                    btn.addEventListener('click', () => {
                        grid.querySelectorAll('.btn-horario').forEach(b => b.classList.remove('selecionado'));
                        btn.classList.add('selecionado');
                        horarioSelecionado = h;
                        inputHorario.value = h;
                        btnRemarcar.disabled = false;
                    });

                    grid.appendChild(btn);
                });

                horariosBox.innerHTML = '';
                horariosBox.appendChild(grid);
            })
            .catch(() => {
                horariosBox.innerHTML = '<p class="hint hint-erro">Erro ao carregar horários.</p>';
            });
    }

    inputData.addEventListener('change', buscarHorarios);

    // Se já há data preenchida (erro de validação), busca automaticamente
    if (inputData.value) buscarHorarios();
})();
</script>

</body>
</html>

