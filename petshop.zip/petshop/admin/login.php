<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';

if (!empty($_SESSION['usuario_id']) && $_SESSION['perfil'] === 'admin') {
    header('Location: /petshop/admin/dashboard.php');
    exit;
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if (!$email || !$senha) {
        $erro = 'Preencha e-mail e senha.';
    } else {
        $pdo  = getDB();
        $stmt = $pdo->prepare('SELECT id, nome, senha_hash, perfil FROM usuarios WHERE email = ?');
        $stmt->execute([$email]);
        $usuario = $stmt->fetch();

        if (!$usuario || $usuario['perfil'] !== 'admin' || !password_verify($senha, $usuario['senha_hash'])) {
            $erro = 'Credenciais inválidas.';
        } else {
            session_regenerate_id(true);
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['nome']       = $usuario['nome'];
            $_SESSION['perfil']     = $usuario['perfil'];
            header('Location: /petshop/admin/dashboard.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin — Patinhas & Cia</title>
    <link rel="stylesheet" href="/petshop/assets/css/style.css">
</head>
<body class="auth-page auth-admin">

<div class="auth-card">
    <div class="auth-logo">
        <span class="logo-icon">🔒</span>
        <h1>Patinhas & Cia</h1>
        <p>Painel Administrativo</p>
    </div>

    <?php if ($erro): ?>
        <div class="alert alert-erro"><?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>

    <form method="POST" novalidate>
        <div class="campo">
            <label for="email">E-mail</label>
            <input type="email" id="email" name="email" required autofocus
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
        </div>
        <div class="campo">
            <label for="senha">Senha</label>
            <input type="password" id="senha" name="senha" required>
        </div>
        <button type="submit" class="btn btn-admin btn-block">Entrar no Painel</button>
    </form>
</div>

</body>
</html>

