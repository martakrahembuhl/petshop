<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/duracao.php';

requireAdmin();

$pdo     = getDB();
$sucesso = '';
$erro    = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $campos = [
        'nome_loja', 'telefone_loja', 'endereco_loja', 'instagram_loja',
        'descricao_loja', 'taxa_taxipet', 'horario_abertura', 'horario_fechamento',
    ];

    try {
        $stmt = $pdo->prepare("UPDATE configuracoes SET valor = ? WHERE chave = ?");
        foreach ($campos as $chave) {
            $valor = trim($_POST[$chave] ?? '');
            if ($chave === 'taxa_taxipet') {
                $valor = number_format((float)str_replace(',', '.', $valor), 2, '.', '');
            }
            $stmt->execute([$valor, $chave]);
        }
        $sucesso = 'Configurações salvas com sucesso!';
    } catch (Exception $e) {
        $erro = 'Erro ao salvar. Tente novamente.';
    }
}

// Carrega todas as configs
$stmt = $pdo->query("SELECT chave, valor FROM configuracoes");
$configs = [];
foreach ($stmt->fetchAll() as $row) {
    $configs[$row['chave']] = $row['valor'];
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurações — Patinhas & Cia Admin</title>
    <link rel="stylesheet" href="/petshop/assets/css/style.css">
    <link rel="stylesheet" href="/petshop/assets/css/admin.css">
</head>
<body class="app-page app-admin">

<header class="app-header admin-header">
    <div class="header-inner">
        <span class="logo-icon">🐾</span>
        <span class="header-title">Patinhas & Cia <em>Admin</em></span>
        <nav class="header-nav">
            <a href="/petshop/admin/dashboard.php" class="btn btn-outline btn-sm">← Dashboard</a>
            <a href="/petshop/admin/logout.php" class="btn btn-outline btn-sm">Sair</a>
        </nav>
    </div>
</header>

<main class="app-main">
    <div class="container">

        <?php if ($sucesso): ?><div class="alert alert-sucesso"><?= htmlspecialchars($sucesso) ?></div><?php endif; ?>
        <?php if ($erro):    ?><div class="alert alert-erro"><?= htmlspecialchars($erro) ?></div><?php endif; ?>

        <section class="card">
            <h2 class="card-title">⚙️ Configurações da Loja</h2>

            <form method="POST" novalidate>
                <fieldset>
                    <legend>Informações da loja</legend>
                    <div class="form-row">
                        <div class="campo">
                            <label for="nome_loja">Nome da loja</label>
                            <input type="text" id="nome_loja" name="nome_loja"
                                   value="<?= htmlspecialchars($configs['nome_loja'] ?? '') ?>">
                        </div>
                        <div class="campo">
                            <label for="telefone_loja">Telefone / WhatsApp</label>
                            <input type="text" id="telefone_loja" name="telefone_loja"
                                   value="<?= htmlspecialchars($configs['telefone_loja'] ?? '') ?>">
                        </div>
                        <div class="campo">
                            <label for="instagram_loja">Instagram</label>
                            <input type="text" id="instagram_loja" name="instagram_loja"
                                   value="<?= htmlspecialchars($configs['instagram_loja'] ?? '') ?>">
                        </div>
                    </div>
                    <div class="campo">
                        <label for="endereco_loja">Endereço</label>
                        <input type="text" id="endereco_loja" name="endereco_loja"
                               value="<?= htmlspecialchars($configs['endereco_loja'] ?? '') ?>">
                    </div>
                    <div class="campo">
                        <label for="descricao_loja">Slogan / Descrição</label>
                        <input type="text" id="descricao_loja" name="descricao_loja"
                               value="<?= htmlspecialchars($configs['descricao_loja'] ?? '') ?>">
                    </div>
                </fieldset>

                <fieldset>
                    <legend>Horários e taxas</legend>
                    <div class="form-row">
                        <div class="campo">
                            <label for="horario_abertura">Abertura</label>
                            <input type="time" id="horario_abertura" name="horario_abertura"
                                   value="<?= htmlspecialchars($configs['horario_abertura'] ?? '08:00') ?>">
                        </div>
                        <div class="campo">
                            <label for="horario_fechamento">Fechamento</label>
                            <input type="time" id="horario_fechamento" name="horario_fechamento"
                                   value="<?= htmlspecialchars($configs['horario_fechamento'] ?? '18:00') ?>">
                        </div>
                        <div class="campo">
                            <label for="taxa_taxipet">Taxa TaxiPet (R$)</label>
                            <input type="number" id="taxa_taxipet" name="taxa_taxipet"
                                   min="0" step="0.01"
                                   value="<?= htmlspecialchars($configs['taxa_taxipet'] ?? '25.00') ?>">
                        </div>
                    </div>
                </fieldset>

                <button type="submit" class="btn btn-admin">Salvar configurações</button>
            </form>
        </section>

    </div>
</main>
</body>
</html>

