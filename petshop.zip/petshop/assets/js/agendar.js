﻿/**
 * agendar.js v3 — Lógica completa de agendamento
 */

(function () {
    'use strict';

    // ── DOM ───────────────────────────────────────────────────────────────────
    const selPet        = document.getElementById('pet_id');
    const selServico    = document.getElementById('servico_id');
    const inputData     = document.getElementById('data');
    const horariosBox   = document.getElementById('horarios-container');
    const inputHorario  = document.getElementById('horario');
    const btnAgendar    = document.getElementById('btn-agendar');
    const formAlerta    = document.getElementById('form-alerta');
    const form          = document.getElementById('form-agendar');
    const selPagamento  = document.getElementById('pagamento');
    const selTransporte = document.getElementById('transporte');
    const resumoBox     = document.getElementById('resumo-servico');
    const resDuracao    = document.getElementById('res-duracao');
    const resPreco      = document.getElementById('res-preco');
    const totalBox      = document.getElementById('total-box');
    const totalValor    = document.getElementById('total-valor');

    if (!form) return;

    let horarioSelecionado = null;

    // ── Helpers ───────────────────────────────────────────────────────────────
    function getPorte() {
        const opt = selPet.options[selPet.selectedIndex];
        return (opt && opt.value) ? (opt.getAttribute('data-porte') || '') : '';
    }

    function getServicoData() {
        const opt = selServico.options[selServico.selectedIndex];
        if (!opt || !opt.value) return null;
        return {
            tempo:       parseInt(opt.getAttribute('data-tempo')        || '0', 10),
            preco:       parseFloat(opt.getAttribute('data-preco')      || '0'),
            precoMedio:  parseFloat(opt.getAttribute('data-preco-medio')  || '0'),
            precoGrande: parseFloat(opt.getAttribute('data-preco-grande') || '0'),
        };
    }

    function calcDuracao(tempo, porte) {
        const adicionais = { pequeno: 0, medio: 15, grande: 30 };
        return tempo + (adicionais[porte] || 0);
    }

    function calcPreco(sd, porte) {
        if (!sd) return 0;
        if (porte === 'medio')  return sd.preco + sd.precoMedio;
        if (porte === 'grande') return sd.preco + sd.precoGrande;
        return sd.preco;
    }

    function fmtMoeda(v) {
        return 'R$ ' + Number(v).toFixed(2).replace('.', ',');
    }

    function mostrarAlerta(msg, tipo) {
        formAlerta.textContent = msg;
        formAlerta.className   = 'alert alert-' + tipo;
        formAlerta.style.display = 'block';
        formAlerta.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    function ocultarAlerta() {
        formAlerta.style.display = 'none';
    }

    function resetHorarios(msg) {
        horariosBox.innerHTML  = '<p class="hint">' + msg + '</p>';
        inputHorario.value     = '';
        horarioSelecionado     = null;
        btnAgendar.disabled    = true;
    }

    // ── Resumo duração + preço ────────────────────────────────────────────────
    function atualizarResumo() {
        const porte = getPorte();
        const sd    = getServicoData();

        if (!porte || !sd) {
            resumoBox.style.display = 'none';
            totalBox.style.display  = 'none';
            return;
        }

        const duracao = calcDuracao(sd.tempo, porte);
        const preco   = calcPreco(sd, porte);
        const taxa    = (selTransporte && selTransporte.value === 'taxipet')
                        ? (typeof TAXA_TAXIPET !== 'undefined' ? TAXA_TAXIPET : 0)
                        : 0;
        const total   = preco + taxa;

        resDuracao.textContent  = duracao + ' minutos';
        resPreco.textContent    = fmtMoeda(preco);
        resumoBox.style.display = 'flex';
        totalValor.textContent  = fmtMoeda(total);
        totalBox.style.display  = 'flex';
    }

    // ── Busca horários ────────────────────────────────────────────────────────
    function buscarHorarios() {
        const petId     = selPet.value;
        const servicoId = selServico.value;
        const data      = inputData.value;
        const porte     = getPorte();

        if (!petId || !servicoId || !data || !porte) {
            resetHorarios('Selecione pet, serviço e data para ver os horários.');
            return;
        }

        horariosBox.innerHTML = '<p class="hint carregando">Buscando horários disponíveis…</p>';
        inputHorario.value    = '';
        horarioSelecionado    = null;
        btnAgendar.disabled   = true;

        const url = '/petshop/api/horarios_disponiveis.php'
            + '?data='       + encodeURIComponent(data)
            + '&servico_id=' + encodeURIComponent(servicoId)
            + '&porte='      + encodeURIComponent(porte);

        fetch(url)
            .then(function(r) {
                if (!r.ok) {
                    return r.text().then(function(t) {
                        throw new Error('HTTP ' + r.status + ': ' + t.substring(0, 200));
                    });
                }
                return r.json();
            })
            .then(function(dados) {
                if (dados.erro) {
                    resetHorarios('Erro: ' + dados.erro);
                    return;
                }
                atualizarResumo();
                renderizarHorarios(dados.horarios);
            })
            .catch(function(err) {
                console.error('Erro horarios_disponiveis:', err);
                resetHorarios('Erro ao carregar horários: ' + err.message);
            });
    }

    // ── Renderiza botões de horário ───────────────────────────────────────────
    function renderizarHorarios(horarios) {
        if (!horarios || !horarios.length) {
            horariosBox.innerHTML = '<p class="hint hint-erro">Nenhum horário disponível nesta data.</p>';
            return;
        }

        const grid = document.createElement('div');
        grid.className = 'horarios-grid';

        horarios.forEach(function(h) {
            const btn = document.createElement('button');
            btn.type      = 'button';
            btn.className = 'btn-horario';
            btn.textContent = h;

            btn.addEventListener('click', function() {
                grid.querySelectorAll('.btn-horario').forEach(function(b) {
                    b.classList.remove('selecionado');
                });
                btn.classList.add('selecionado');
                horarioSelecionado    = h;
                inputHorario.value    = h;
                btnAgendar.disabled   = false;
                ocultarAlerta();
            });

            grid.appendChild(btn);
        });

        horariosBox.innerHTML = '';
        horariosBox.appendChild(grid);
    }

    // ── Envio do formulário ───────────────────────────────────────────────────
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        if (!selPet.value || !selServico.value || !inputData.value || !horarioSelecionado) {
            mostrarAlerta('Preencha todos os campos e selecione um horário.', 'erro');
            return;
        }

        btnAgendar.disabled     = true;
        btnAgendar.textContent  = 'Aguarde…';
        ocultarAlerta();

        const payload = {
            pet_id:     parseInt(selPet.value, 10),
            servico_id: parseInt(selServico.value, 10),
            data:       inputData.value,
            horario:    horarioSelecionado,
            pagamento:  selPagamento ? selPagamento.value : 'pix',
            transporte: selTransporte ? selTransporte.value : 'proprio',
        };

        fetch('/petshop/api/agendamento.php', {
            method:  'POST',
            headers: { 'Content-Type': 'application/json' },
            body:    JSON.stringify(payload),
        })
        .then(function(r) {
            // Lê como texto primeiro para evitar erro de parse
            return r.text().then(function(txt) {
                try {
                    return JSON.parse(txt);
                } catch (err) {
                    throw new Error('Resposta inválida do servidor: ' + txt.substring(0, 300));
                }
            });
        })
        .then(function(dados) {
            if (dados.sucesso) {
                mostrarAlerta(
                    '✅ ' + dados.mensagem
                    + ' — ' + dados.inicio + ' até ' + dados.fim
                    + ' | Total: ' + dados.valor_total,
                    'sucesso'
                );
                form.reset();
                resetHorarios('Selecione pet, serviço e data para ver os horários.');
                if (resumoBox) resumoBox.style.display = 'none';
                if (totalBox)  totalBox.style.display  = 'none';
                setTimeout(function() { location.reload(); }, 2500);
            } else {
                mostrarAlerta('❌ ' + (dados.erro || 'Erro ao agendar.'), 'erro');
                btnAgendar.disabled    = false;
                btnAgendar.textContent = 'Confirmar Agendamento';
            }
        })
        .catch(function(err) {
            console.error('Erro agendamento:', err);
            mostrarAlerta('Erro: ' + err.message, 'erro');
            btnAgendar.disabled    = false;
            btnAgendar.textContent = 'Confirmar Agendamento';
        });
    });

    // ── Listeners ─────────────────────────────────────────────────────────────
    selPet.addEventListener('change',     function() { atualizarResumo(); buscarHorarios(); });
    selServico.addEventListener('change', function() { atualizarResumo(); buscarHorarios(); });
    inputData.addEventListener('change',  buscarHorarios);
    if (selTransporte) selTransporte.addEventListener('change', atualizarResumo);

})();
