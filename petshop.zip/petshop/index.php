<?php
require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/duracao.php';

// Se já logado, redireciona direto
if (!empty($_SESSION['usuario_id'])) {
    header('Location: ' . ($_SESSION['perfil'] === 'admin'
        ? '/petshop/admin/dashboard.php'
        : '/petshop/cliente/agendar.php'));
    exit;
}

$pdo = getDB();
$nomeLoja    = getConfig($pdo, 'nome_loja',      'Patinhas & Cia');
$descLoja    = getConfig($pdo, 'descricao_loja', 'Cuidado e carinho para o seu melhor amigo!');
$telLoja     = getConfig($pdo, 'telefone_loja',  '');
$endLoja     = getConfig($pdo, 'endereco_loja',  '');
$instaLoja   = getConfig($pdo, 'instagram_loja', '');

$servicos = $pdo->query("SELECT nome, preco, preco_adicional_medio, preco_adicional_grande, tempo_base_min FROM servicos WHERE ativo = 1 ORDER BY nome")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($nomeLoja) ?> — Agendamento Online</title>
    <link rel="stylesheet" href="/petshop/assets/css/style.css">
    <link rel="stylesheet" href="/petshop/assets/css/landing.css">
</head>
<body class="landing-page">

<!-- ── Navbar ──────────────────────────────────────────────── -->
<nav class="navbar">
    <div class="navbar-inner">
        <a href="/petshop/" class="navbar-brand">
            <span class="logo-icon">🐾</span>
            <strong><?= htmlspecialchars($nomeLoja) ?></strong>
        </a>
        <div class="navbar-links">
            <a href="#servicos">Serviços</a>
            <a href="#como-funciona">Como funciona</a>
            <a href="#contato">Contato</a>
            <a href="/petshop/cliente/login.php" class="btn btn-outline btn-sm">Entrar</a>
            <a href="/petshop/cliente/cadastro.php" class="btn btn-primary btn-sm">Agendar agora</a>
        </div>
        <button class="navbar-toggle" onclick="toggleMenu()" aria-label="Menu">☰</button>
    </div>
    <div class="navbar-mobile" id="navbar-mobile">
        <a href="#servicos" onclick="toggleMenu()">Serviços</a>
        <a href="#como-funciona" onclick="toggleMenu()">Como funciona</a>
        <a href="#contato" onclick="toggleMenu()">Contato</a>
        <a href="/petshop/cliente/login.php">Entrar</a>
        <a href="/petshop/cliente/cadastro.php" class="btn btn-primary">Agendar agora</a>
    </div>
</nav>

<!-- ── Hero ────────────────────────────────────────────────── -->
<section class="hero">
    <div class="hero-content">
        <span class="hero-badge">🐶 Agendamento 100% online</span>
        <h1>Seu pet merece o<br><span class="hero-destaque">melhor cuidado</span></h1>
        <p class="hero-sub"><?= htmlspecialchars($descLoja) ?></p>
        <div class="hero-ctas">
            <a href="/petshop/cliente/cadastro.php" class="btn btn-hero-primary">
                Agendar agora →
            </a>
            <a href="#servicos" class="btn btn-hero-outline">Ver serviços</a>
        </div>
        <div class="hero-stats">
            <div class="hero-stat"><strong>🕐</strong><span>Horários flexíveis</span></div>
            <div class="hero-stat"><strong>🚗</strong><span>TaxiPet disponível</span></div>
            <div class="hero-stat"><strong>💳</strong><span>Várias formas de pagamento</span></div>
        </div>
    </div>
    <div class="hero-image">
        <div class="hero-img-placeholder">🐾</div>
    </div>
</section>

<!-- ── Serviços ─────────────────────────────────────────────── -->
<section class="section" id="servicos">
    <div class="section-inner">
        <div class="section-header">
            <h2>Nossos Serviços</h2>
            <p>Preços variam conforme o porte do pet</p>
        </div>
        <div class="servicos-grid">
            <?php
            $icones = ['Banho' => '🛁', 'Tosa' => '✂️', 'Consulta' => '🩺'];
            foreach ($servicos as $s):
                $icone = $icones[$s['nome']] ?? '🐾';
            ?>
            <div class="servico-card">
                <div class="servico-icone"><?= $icone ?></div>
                <h3><?= htmlspecialchars($s['nome']) ?></h3>
                <p class="servico-tempo">⏱ <?= $s['tempo_base_min'] ?> min (base)</p>
                <div class="servico-precos">
                    <div class="preco-linha">
                        <span>Pequeno</span>
                        <strong>R$ <?= number_format($s['preco'], 2, ',', '.') ?></strong>
                    </div>
                    <div class="preco-linha">
                        <span>Médio</span>
                        <strong>R$ <?= number_format($s['preco'] + $s['preco_adicional_medio'], 2, ',', '.') ?></strong>
                    </div>
                    <div class="preco-linha">
                        <span>Grande</span>
                        <strong>R$ <?= number_format($s['preco'] + $s['preco_adicional_grande'], 2, ',', '.') ?></strong>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>

            <!-- Card TaxiPet -->
            <div class="servico-card servico-card-destaque">
                <div class="servico-icone">🚗</div>
                <h3>TaxiPet</h3>
                <p class="servico-tempo">Buscamos e levamos seu pet</p>
                <div class="servico-precos">
                    <div class="preco-linha">
                        <span>Taxa de transporte</span>
                        <?php
                        $taxa = getConfig($pdo, 'taxa_taxipet', '25.00');
                        ?>
                        <strong>R$ <?= number_format((float)$taxa, 2, ',', '.') ?></strong>
                    </div>
                </div>
                <p class="servico-obs">Disponível ao agendar</p>
            </div>
        </div>
    </div>
</section>

<!-- ── Como funciona ────────────────────────────────────────── -->
<section class="section section-alt" id="como-funciona">
    <div class="section-inner">
        <div class="section-header">
            <h2>Como funciona</h2>
            <p>Agendar é simples e rápido</p>
        </div>
        <div class="steps-grid">
            <div class="step">
                <div class="step-num">1</div>
                <h3>Crie sua conta</h3>
                <p>Cadastre-se com nome, telefone e e-mail. Adicione quantos pets quiser.</p>
            </div>
            <div class="step">
                <div class="step-num">2</div>
                <h3>Escolha o serviço</h3>
                <p>Selecione o pet, o serviço desejado e veja os horários disponíveis em tempo real.</p>
            </div>
            <div class="step">
                <div class="step-num">3</div>
                <h3>Confirme e pronto</h3>
                <p>Escolha a forma de pagamento e se precisa de TaxiPet. Agendamento feito!</p>
            </div>
        </div>
    </div>
</section>

<!-- ── Contato ──────────────────────────────────────────────── -->
<section class="section" id="contato">
    <div class="section-inner">
        <div class="section-header">
            <h2>Onde estamos</h2>
        </div>
        <div class="contato-grid">
            <div class="contato-item">
                <span class="contato-icone">📍</span>
                <div>
                    <strong>Endereço</strong>
                    <p><?= htmlspecialchars($endLoja) ?></p>
                </div>
            </div>
            <div class="contato-item">
                <span class="contato-icone">📞</span>
                <div>
                    <strong>Telefone / WhatsApp</strong>
                    <p><?= htmlspecialchars($telLoja) ?></p>
                </div>
            </div>
            <?php if ($instaLoja): ?>
            <div class="contato-item">
                <span class="contato-icone">📸</span>
                <div>
                    <strong>Instagram</strong>
                    <p><?= htmlspecialchars($instaLoja) ?></p>
                </div>
            </div>
            <?php endif; ?>
            <div class="contato-item">
                <span class="contato-icone">🕐</span>
                <div>
                    <strong>Horário de funcionamento</strong>
                    <p>
                        <?= getConfig($pdo, 'horario_abertura', '08:00') ?>
                        às
                        <?= getConfig($pdo, 'horario_fechamento', '18:00') ?>
                        — Seg a Sáb
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ── CTA final ────────────────────────────────────────────── -->
<section class="cta-final">
    <div class="section-inner" style="text-align:center">
        <h2>Pronto para agendar?</h2>
        <p>Crie sua conta gratuitamente e agende em minutos.</p>
        <a href="/petshop/cliente/cadastro.php" class="btn btn-hero-primary" style="margin-top:1.5rem">
            Criar conta e agendar →
        </a>
    </div>
</section>

<!-- ── Footer ───────────────────────────────────────────────── -->
<footer class="footer">
    <p>© <?= date('Y') ?> <?= htmlspecialchars($nomeLoja) ?> — Todos os direitos reservados</p>
</footer>

<script>
function toggleMenu() {
    const m = document.getElementById('navbar-mobile');
    m.classList.toggle('open');
}
</script>
</body>
</html>

