<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';

requireCliente();

$pdo  = getDB();
$erro = '';
$sucesso = '';

// ── Ações POST ────────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao  = $_POST['acao'] ?? '';
    $portesValidos = ['pequeno', 'medio', 'grande'];

    if ($acao === 'adicionar') {
        $nome  = trim($_POST['nome']  ?? '');
        $raca  = trim($_POST['raca']  ?? '');
        $porte = $_POST['porte'] ?? '';

        if (!$nome || !$raca || !in_array($porte, $portesValidos)) {
            $erro = 'Preencha todos os campos do pet.';
        } else {
            $stmt = $pdo->prepare('INSERT INTO pets (usuario_id, nome, raca, porte) VALUES (?, ?, ?, ?)');
            $stmt->execute([$_SESSION['usuario_id'], $nome, $raca, $porte]);
            $sucesso = "Pet \"{$nome}\" adicionado com sucesso!";
        }

    } elseif ($acao === 'editar') {
        $id    = (int)($_POST['pet_id'] ?? 0);
        $nome  = trim($_POST['nome']  ?? '');
        $raca  = trim($_POST['raca']  ?? '');
        $porte = $_POST['porte'] ?? '';

        if ($id <= 0 || !$nome || !$raca || !in_array($porte, $portesValidos)) {
            $erro = 'Dados inválidos para edição.';
        } else {
            // Garante que o pet pertence ao cliente
            $stmt = $pdo->prepare('UPDATE pets SET nome=?, raca=?, porte=? WHERE id=? AND usuario_id=?');
            $stmt->execute([$nome, $raca, $porte, $id, $_SESSION['usuario_id']]);
            $sucesso = "Pet atualizado com sucesso!";
        }

    } elseif ($acao === 'remover') {
        $id = (int)($_POST['pet_id'] ?? 0);
        if ($id > 0) {
            // Verifica se tem agendamentos futuros
            $stmt = $pdo->prepare(
                "SELECT COUNT(*) FROM agendamentos
                 WHERE pet_id = ? AND status = 'agendado' AND data_hora_inicio > NOW()"
            );
            $stmt->execute([$id]);
            if ((int)$stmt->fetchColumn() > 0) {
                $erro = 'Não é possível remover: este pet tem agendamentos futuros.';
            } else {
                $stmt = $pdo->prepare('DELETE FROM pets WHERE id = ? AND usuario_id = ?');
                $stmt->execute([$id, $_SESSION['usuario_id']]);
                $sucesso = 'Pet removido.';
            }
        }
    }
}

// Busca pets do cliente
$stmt = $pdo->prepare('SELECT id, nome, raca, porte FROM pets WHERE usuario_id = ? ORDER BY nome');
$stmt->execute([$_SESSION['usuario_id']]);
$pets = $stmt->fetchAll();

$portesLabel = ['pequeno' => 'Pequeno', 'medio' => 'Médio', 'grande' => 'Grande'];
$portesIcone = ['pequeno' => '🐩', 'medio' => '🐕', 'grande' => '🦮'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meus Pets — Patinhas & Cia</title>
    <link rel="stylesheet" href="/petshop/assets/css/style.css">
</head>
<body class="app-page">

<header class="app-header">
    <div class="header-inner">
        <span class="logo-icon">🐾</span>
        <span class="header-title">Patinhas & Cia</span>
        <nav class="header-nav">
            <a href="/petshop/cliente/agendar.php" class="btn btn-outline btn-sm">📅 Agendar</a>
            <a href="/petshop/cliente/logout.php"  class="btn btn-outline btn-sm">Sair</a>
        </nav>
    </div>
</header>

<main class="app-main">
    <div class="container">

        <?php if ($erro):    ?><div class="alert alert-erro"><?= htmlspecialchars($erro) ?></div><?php endif; ?>
        <?php if ($sucesso): ?><div class="alert alert-sucesso"><?= htmlspecialchars($sucesso) ?></div><?php endif; ?>

        <!-- ── Lista de pets ──────────────────────────────────────────────── -->
        <section class="card">
            <h2 class="card-title">Meus Pets (<?= count($pets) ?>)</h2>

            <?php if (empty($pets)): ?>
                <p class="hint">Você ainda não tem pets cadastrados. Adicione um abaixo.</p>
            <?php else: ?>
            <div class="pets-grid">
                <?php foreach ($pets as $pet): ?>
                <div class="pet-card">
                    <div class="pet-icone"><?= $portesIcone[$pet['porte']] ?></div>
                    <div class="pet-info">
                        <strong><?= htmlspecialchars($pet['nome']) ?></strong>
                        <span><?= htmlspecialchars($pet['raca']) ?></span>
                        <span class="badge badge-porte"><?= $portesLabel[$pet['porte']] ?></span>
                    </div>
                    <div class="pet-acoes">
                        <button type="button" class="btn btn-sm btn-outline"
                                onclick="abrirEditar(<?= $pet['id'] ?>, '<?= htmlspecialchars(addslashes($pet['nome'])) ?>', '<?= htmlspecialchars(addslashes($pet['raca'])) ?>', '<?= $pet['porte'] ?>')">
                            ✏️ Editar
                        </button>
                        <form method="POST" style="display:inline"
                              onsubmit="return confirm('Remover <?= htmlspecialchars(addslashes($pet['nome'])) ?>?')">
                            <input type="hidden" name="acao"   value="remover">
                            <input type="hidden" name="pet_id" value="<?= $pet['id'] ?>">
                            <button type="submit" class="btn btn-sm btn-danger">🗑 Remover</button>
                        </form>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </section>

        <!-- ── Adicionar pet ──────────────────────────────────────────────── -->
        <section class="card">
            <h2 class="card-title">Adicionar Novo Pet</h2>
            <form method="POST" novalidate>
                <input type="hidden" name="acao" value="adicionar">
                <div class="form-row">
                    <div class="campo">
                        <label for="nome">Nome do pet</label>
                        <input type="text" id="nome" name="nome" required
                               placeholder="Ex: Rex">
                    </div>
                    <div class="campo">
                        <label for="raca">Raça</label>
                        <input type="text" id="raca" name="raca" required
                               placeholder="Ex: Golden Retriever">
                    </div>
                    <div class="campo">
                        <label for="porte">Porte</label>
                        <select id="porte" name="porte" required>
                            <option value="">Selecione…</option>
                            <option value="pequeno">Pequeno (até 10kg)</option>
                            <option value="medio">Médio (10–25kg)</option>
                            <option value="grande">Grande (acima de 25kg)</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Adicionar pet</button>
            </form>
        </section>

    </div>
</main>

<!-- Modal de edição -->
<div id="modal-editar" class="modal" style="display:none" role="dialog" aria-modal="true">
    <div class="modal-overlay" onclick="fecharModal()"></div>
    <div class="modal-box">
        <h3>Editar Pet</h3>
        <form method="POST" novalidate>
            <input type="hidden" name="acao"   value="editar">
            <input type="hidden" name="pet_id" id="edit-id">
            <div class="campo">
                <label for="edit-nome">Nome</label>
                <input type="text" id="edit-nome" name="nome" required>
            </div>
            <div class="campo">
                <label for="edit-raca">Raça</label>
                <input type="text" id="edit-raca" name="raca" required>
            </div>
            <div class="campo">
                <label for="edit-porte">Porte</label>
                <select id="edit-porte" name="porte" required>
                    <option value="pequeno">Pequeno</option>
                    <option value="medio">Médio</option>
                    <option value="grande">Grande</option>
                </select>
            </div>
            <div class="modal-acoes">
                <button type="button" class="btn btn-outline" onclick="fecharModal()">Cancelar</button>
                <button type="submit" class="btn btn-primary">Salvar</button>
            </div>
        </form>
    </div>
</div>

<script>
function abrirEditar(id, nome, raca, porte) {
    document.getElementById('edit-id').value    = id;
    document.getElementById('edit-nome').value  = nome;
    document.getElementById('edit-raca').value  = raca;
    document.getElementById('edit-porte').value = porte;
    document.getElementById('modal-editar').style.display = 'flex';
}
function fecharModal() {
    document.getElementById('modal-editar').style.display = 'none';
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') fecharModal(); });
</script>
</body>
</html>

