<?php
/**
 * Cancela um agendamento pelo próprio cliente.
 * POST /cliente/desmarcar.php
 */

require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';

requireCliente();

$id = (int)($_POST['agendamento_id'] ?? 0);

if ($id <= 0) {
    header('Location: /petshop/cliente/agendar.php?msg=erro');
    exit;
}

$pdo = getDB();

// Garante que o agendamento pertence ao cliente logado,
// está com status 'agendado' e ainda não aconteceu
$stmt = $pdo->prepare(
    "UPDATE agendamentos
     SET status = 'cancelado'
     WHERE id = ?
       AND usuario_id = ?
       AND status = 'agendado'
       AND data_hora_inicio > NOW()"
);
$stmt->execute([$id, $_SESSION['usuario_id']]);

if ($stmt->rowCount() > 0) {
    header('Location: /petshop/cliente/agendar.php?msg=desmarcado');
} else {
    header('Location: /petshop/cliente/agendar.php?msg=erro');
}
exit;

