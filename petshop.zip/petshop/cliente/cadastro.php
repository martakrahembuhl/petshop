<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';

if (!empty($_SESSION['usuario_id']) && $_SESSION['perfil'] === 'cliente') {
    header('Location: /petshop/cliente/agendar.php');
    exit;
}

$erro    = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome     = trim($_POST['nome']     ?? '');
    $telefone = trim($_POST['telefone'] ?? '');
    $email    = trim($_POST['email']    ?? '');
    $senha    = $_POST['senha']         ?? '';

    // Pets vêm como arrays: pet_nome[], pet_raca[], pet_porte[]
    $petNomes  = array_map('trim', $_POST['pet_nome']  ?? []);
    $petRacas  = array_map('trim', $_POST['pet_raca']  ?? []);
    $petPortes = $_POST['pet_porte'] ?? [];

    $portesValidos = ['pequeno', 'medio', 'grande'];

    // Filtra pets com todos os campos preenchidos
    $petsValidos = [];
    foreach ($petNomes as $i => $pNome) {
        $pRaca  = $petRacas[$i]  ?? '';
        $pPorte = $petPortes[$i] ?? '';
        if ($pNome && $pRaca && in_array($pPorte, $portesValidos)) {
            $petsValidos[] = ['nome' => $pNome, 'raca' => $pRaca, 'porte' => $pPorte];
        }
    }

    if (!$nome || !$telefone || !$email || !$senha) {
        $erro = 'Preencha todos os seus dados pessoais.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = 'E-mail inválido.';
    } elseif (strlen($senha) < 6) {
        $erro = 'A senha deve ter pelo menos 6 caracteres.';
    } elseif (empty($petsValidos)) {
        $erro = 'Cadastre pelo menos um pet com todos os campos preenchidos.';
    } else {
        $pdo = getDB();

        $stmt = $pdo->prepare('SELECT id FROM usuarios WHERE email = ?');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $erro = 'Este e-mail já está cadastrado.';
        } else {
            $hash = password_hash($senha, PASSWORD_BCRYPT, ['cost' => 12]);
            $pdo->beginTransaction();
            try {
                $stmt = $pdo->prepare(
                    'INSERT INTO usuarios (nome, telefone, email, senha_hash, perfil) VALUES (?, ?, ?, ?, "cliente")'
                );
                $stmt->execute([$nome, $telefone, $email, $hash]);
                $usuarioId = (int)$pdo->lastInsertId();

                $stmtPet = $pdo->prepare(
                    'INSERT INTO pets (usuario_id, nome, raca, porte) VALUES (?, ?, ?, ?)'
                );
                foreach ($petsValidos as $p) {
                    $stmtPet->execute([$usuarioId, $p['nome'], $p['raca'], $p['porte']]);
                }

                $pdo->commit();
                $sucesso = 'Cadastro realizado com ' . count($petsValidos) . ' pet(s)! Faça login para agendar.';
            } catch (Exception $e) {
                $pdo->rollBack();
                $erro = 'Erro ao salvar. Tente novamente.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro — Patinhas & Cia</title>
    <link rel="stylesheet" href="/petshop/assets/css/style.css">
    <style>
        .pet-bloco {
            border: 1.5px solid var(--cor-borda);
            border-radius: var(--raio);
            padding: 1rem 1.25rem;
            margin-bottom: 1rem;
            position: relative;
            background: #fafbfc;
        }
        .pet-bloco-titulo {
            font-size: .82rem;
            font-weight: 700;
            color: var(--cor-texto-leve);
            text-transform: uppercase;
            letter-spacing: .05em;
            margin-bottom: .75rem;
        }
        .btn-remover-pet {
            position: absolute;
            top: .75rem;
            right: .75rem;
            background: none;
            border: none;
            color: var(--cor-perigo);
            cursor: pointer;
            font-size: 1.1rem;
            line-height: 1;
            padding: .2rem .4rem;
            border-radius: 4px;
        }
        .btn-remover-pet:hover { background: #ffebee; }
        .btn-add-pet {
            display: flex;
            align-items: center;
            gap: .4rem;
            background: none;
            border: 2px dashed var(--cor-primaria);
            color: var(--cor-primaria);
            border-radius: var(--raio);
            padding: .6rem 1rem;
            font-size: .9rem;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
            justify-content: center;
            margin-bottom: 1rem;
            transition: background .2s;
        }
        .btn-add-pet:hover { background: #e8f5e9; }
        .auth-card { max-width: 520px; }
    </style>
</head>
<body class="auth-page">

<div class="auth-card">
    <div class="auth-logo">
        <span class="logo-icon">🐾</span>
        <h1>Patinhas & Cia</h1>
        <p>Crie sua conta</p>
    </div>

    <?php if ($erro): ?>
        <div class="alert alert-erro"><?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>

    <?php if ($sucesso): ?>
        <div class="alert alert-sucesso">
            <?= htmlspecialchars($sucesso) ?>
            <br><a href="/petshop/cliente/login.php">Ir para o login →</a>
        </div>
    <?php else: ?>

    <form method="POST" id="form-cadastro" novalidate>

        <!-- ── Dados pessoais ──────────────────────────────────────────── -->
        <fieldset>
            <legend>Seus dados</legend>

            <div class="campo">
                <label for="nome">Nome completo</label>
                <input type="text" id="nome" name="nome" required autofocus
                       value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>">
            </div>

            <div class="campo">
                <label for="telefone">Telefone / WhatsApp</label>
                <input type="tel" id="telefone" name="telefone" required
                       placeholder="(00) 00000-0000"
                       value="<?= htmlspecialchars($_POST['telefone'] ?? '') ?>">
            </div>

            <div class="campo">
                <label for="email">E-mail</label>
                <input type="email" id="email" name="email" required
                       value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                <span class="hint" id="email-hint"></span>
            </div>

            <div class="campo">
                <label for="senha">Senha <small>(mín. 6 caracteres)</small></label>
                <input type="password" id="senha" name="senha" required minlength="6">
            </div>
        </fieldset>

        <!-- ── Pets ────────────────────────────────────────────────────── -->
        <fieldset>
            <legend>Seus Pets</legend>

            <div id="pets-container">
                <!-- Bloco inicial (obrigatório) -->
                <div class="pet-bloco" id="pet-0">
                    <div class="pet-bloco-titulo">🐾 Pet 1</div>
                    <div class="campo">
                        <label>Nome do pet</label>
                        <input type="text" name="pet_nome[]" required
                               placeholder="Ex: Rex"
                               value="<?= htmlspecialchars(($_POST['pet_nome'] ?? [''])[0] ?? '') ?>">
                    </div>
                    <div class="campo">
                        <label>Raça</label>
                        <input type="text" name="pet_raca[]" required
                               placeholder="Ex: Golden Retriever"
                               value="<?= htmlspecialchars(($_POST['pet_raca'] ?? [''])[0] ?? '') ?>">
                    </div>
                    <div class="campo">
                        <label>Porte</label>
                        <select name="pet_porte[]" required>
                            <option value="">Selecione…</option>
                            <option value="pequeno" <?= (($_POST['pet_porte'][0] ?? '') === 'pequeno') ? 'selected' : '' ?>>Pequeno (até 10kg)</option>
                            <option value="medio"   <?= (($_POST['pet_porte'][0] ?? '') === 'medio')   ? 'selected' : '' ?>>Médio (10–25kg)</option>
                            <option value="grande"  <?= (($_POST['pet_porte'][0] ?? '') === 'grande')  ? 'selected' : '' ?>>Grande (acima de 25kg)</option>
                        </select>
                    </div>
                </div>

                <?php
                // Repopula pets extras em caso de erro no POST
                $petNomesPost  = $_POST['pet_nome']  ?? [];
                $petRacasPost  = $_POST['pet_raca']  ?? [];
                $petPortesPost = $_POST['pet_porte'] ?? [];
                for ($i = 1; $i < count($petNomesPost); $i++):
                ?>
                <div class="pet-bloco" id="pet-<?= $i ?>">
                    <div class="pet-bloco-titulo">🐾 Pet <?= $i + 1 ?></div>
                    <button type="button" class="btn-remover-pet" onclick="removerPet(<?= $i ?>)" title="Remover pet">✕</button>
                    <div class="campo">
                        <label>Nome do pet</label>
                        <input type="text" name="pet_nome[]"
                               value="<?= htmlspecialchars($petNomesPost[$i] ?? '') ?>">
                    </div>
                    <div class="campo">
                        <label>Raça</label>
                        <input type="text" name="pet_raca[]"
                               value="<?= htmlspecialchars($petRacasPost[$i] ?? '') ?>">
                    </div>
                    <div class="campo">
                        <label>Porte</label>
                        <select name="pet_porte[]">
                            <option value="">Selecione…</option>
                            <option value="pequeno" <?= (($petPortesPost[$i] ?? '') === 'pequeno') ? 'selected' : '' ?>>Pequeno (até 10kg)</option>
                            <option value="medio"   <?= (($petPortesPost[$i] ?? '') === 'medio')   ? 'selected' : '' ?>>Médio (10–25kg)</option>
                            <option value="grande"  <?= (($petPortesPost[$i] ?? '') === 'grande')  ? 'selected' : '' ?>>Grande (acima de 25kg)</option>
                        </select>
                    </div>
                </div>
                <?php endfor; ?>
            </div>

            <button type="button" class="btn-add-pet" onclick="adicionarPet()">
                + Adicionar outro pet
            </button>
        </fieldset>

        <button type="submit" class="btn btn-primary btn-block">Criar conta</button>
    </form>

    <?php endif; ?>

    <p class="auth-link">Já tem conta? <a href="/petshop/cliente/login.php">Entrar</a></p>
</div>

<script>
let contadorPets = <?= max(1, count($_POST['pet_nome'] ?? [1])) ?>;

function adicionarPet() {
    const container = document.getElementById('pets-container');
    const idx       = contadorPets;
    contadorPets++;

    const bloco = document.createElement('div');
    bloco.className = 'pet-bloco';
    bloco.id = 'pet-' + idx;
    bloco.innerHTML = `
        <div class="pet-bloco-titulo">🐾 Pet ${idx + 1}</div>
        <button type="button" class="btn-remover-pet" onclick="removerPet(${idx})" title="Remover">✕</button>
        <div class="campo">
            <label>Nome do pet</label>
            <input type="text" name="pet_nome[]" placeholder="Ex: Mel">
        </div>
        <div class="campo">
            <label>Raça</label>
            <input type="text" name="pet_raca[]" placeholder="Ex: Poodle">
        </div>
        <div class="campo">
            <label>Porte</label>
            <select name="pet_porte[]">
                <option value="">Selecione…</option>
                <option value="pequeno">Pequeno (até 10kg)</option>
                <option value="medio">Médio (10–25kg)</option>
                <option value="grande">Grande (acima de 25kg)</option>
            </select>
        </div>
    `;

    container.appendChild(bloco);
    bloco.querySelector('input').focus();
    atualizarTitulos();
}

function removerPet(idx) {
    const bloco = document.getElementById('pet-' + idx);
    if (bloco) {
        bloco.remove();
        atualizarTitulos();
    }
}

function atualizarTitulos() {
    const blocos = document.querySelectorAll('.pet-bloco');
    blocos.forEach((b, i) => {
        const titulo = b.querySelector('.pet-bloco-titulo');
        if (titulo) titulo.textContent = '🐾 Pet ' + (i + 1);
    });
}

// Validação AJAX: e-mail duplicado
const emailInput = document.getElementById('email');
const emailHint  = document.getElementById('email-hint');
let debounceTimer;

emailInput.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    const email = emailInput.value.trim();
    if (!email.includes('@')) { emailHint.textContent = ''; return; }

    debounceTimer = setTimeout(() => {
        fetch('/petshop/api/verificar_email.php?email=' + encodeURIComponent(email))
            .then(r => r.json())
            .then(data => {
                if (data.existe) {
                    emailHint.textContent = '⚠ Este e-mail já está cadastrado.';
                    emailHint.className = 'hint hint-erro';
                } else {
                    emailHint.textContent = '✓ E-mail disponível.';
                    emailHint.className = 'hint hint-ok';
                }
            });
    }, 500);
});
</script>
</body>
</html>

