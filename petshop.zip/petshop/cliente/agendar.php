<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/duracao.php';

requireCliente();

$pdo = getDB();

$pets     = $pdo->prepare('SELECT id, nome, raca, porte FROM pets WHERE usuario_id = ? ORDER BY nome');
$pets->execute([$_SESSION['usuario_id']]);
$pets = $pets->fetchAll();

// Verifica se colunas de preço existem em servicos
$colunasServico = [];
foreach ($pdo->query("SHOW COLUMNS FROM servicos")->fetchAll() as $c) {
    $colunasServico[] = $c['Field'];
}
$temPreco = in_array('preco', $colunasServico);

$selectServico = $temPreco
    ? 'id, nome, tempo_base_min, preco, preco_adicional_medio, preco_adicional_grande'
    : 'id, nome, tempo_base_min, 0 AS preco, 0 AS preco_adicional_medio, 0 AS preco_adicional_grande';

$servicos = $pdo->query("SELECT {$selectServico} FROM servicos WHERE ativo = 1 ORDER BY nome")->fetchAll();

// Verifica quais colunas existem na tabela agendamentos
$colunasAgend = [];
foreach ($pdo->query("SHOW COLUMNS FROM agendamentos")->fetchAll() as $c) {
    $colunasAgend[] = $c['Field'];
}
$temColunasPagto = in_array('metodo_pagamento', $colunasAgend);
$temColunasValor = in_array('valor_total', $colunasAgend);

$taxaTaxiPet = getTaxaTaxiPet($pdo);

// Agendamentos futuros
$selectExtra = $temColunasPagto
    ? "a.metodo_pagamento, a.transporte, a.taxa_transporte,"
    : "'pix' AS metodo_pagamento, 'proprio' AS transporte, 0 AS taxa_transporte,";
$selectValor = $temColunasValor
    ? "a.valor_total"
    : "0 AS valor_total";

$stmt = $pdo->prepare(
    "SELECT a.id, a.data_hora_inicio, a.data_hora_fim, a.duracao_min, a.status,
            {$selectExtra}
            {$selectValor},
            p.nome AS pet_nome, s.nome AS servico_nome
     FROM agendamentos a
     JOIN pets     p ON p.id = a.pet_id
     JOIN servicos s ON s.id = a.servico_id
     WHERE a.usuario_id = ?
       AND a.data_hora_inicio >= NOW()
       AND a.status = 'agendado'
     ORDER BY a.data_hora_inicio
     LIMIT 10"
);
$stmt->execute([$_SESSION['usuario_id']]);
$proximosAgendamentos = $stmt->fetchAll();

$portesLabel = ['pequeno' => 'Pequeno', 'medio' => 'Médio', 'grande' => 'Grande'];
$pagtoLabel  = ['dinheiro' => 'Dinheiro', 'debito' => 'Débito', 'credito' => 'Crédito', 'pix' => 'PIX'];
$transpLabel = ['proprio' => 'Próprio', 'taxipet' => 'TaxiPet'];

// Mensagem de retorno
$msg = $_GET['msg'] ?? '';
$msgMap = [
    'desmarcado' => ['tipo' => 'sucesso', 'texto' => 'Agendamento desmarcado com sucesso.'],
    'erro'       => ['tipo' => 'erro',    'texto' => 'Não foi possível desmarcar. O agendamento pode já ter ocorrido ou sido cancelado.'],
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendar — Patinhas & Cia</title>
    <link rel="stylesheet" href="/petshop/assets/css/style.css">
</head>
<body class="app-page">

<header class="app-header">
    <div class="header-inner">
        <span class="logo-icon">🐾</span>
        <span class="header-title">Patinhas & Cia</span>
        <nav class="header-nav">
            <a href="/petshop/cliente/meus_pets.php" class="btn btn-outline btn-sm">🐾 Meus Pets</a>
            <span class="header-user">Olá, <?= htmlspecialchars($_SESSION['nome']) ?></span>
            <a href="/petshop/cliente/logout.php" class="btn btn-outline btn-sm">Sair</a>
        </nav>
    </div>
</header>

<main class="app-main">
    <div class="container">

        <!-- ── Formulário de agendamento ─────────────────────────────────── -->
        <section class="card">
            <h2 class="card-title">📅 Novo Agendamento</h2>

            <div id="form-alerta" class="alert" style="display:none"></div>

            <?php if (empty($pets)): ?>
            <div class="alert alert-aviso">
                Você não tem pets cadastrados.
                <a href="/petshop/cliente/meus_pets.php">Cadastre um pet</a> para agendar.
            </div>
            <?php else: ?>

            <form id="form-agendar" novalidate>

                <div class="form-row">
                    <!-- Pet -->
                    <div class="campo">
                        <label for="pet_id">Pet</label>
                        <select id="pet_id" name="pet_id" required>
                            <option value="">— selecione —</option>
                            <?php foreach ($pets as $pet): ?>
                            <option value="<?= $pet['id'] ?>"
                                    data-porte="<?= $pet['porte'] ?>">
                                <?= htmlspecialchars($pet['nome']) ?>
                                (<?= $portesLabel[$pet['porte']] ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Serviço -->
                    <div class="campo">
                        <label for="servico_id">Serviço</label>
                        <select id="servico_id" name="servico_id" required>
                            <option value="">— selecione —</option>
                            <?php foreach ($servicos as $s): ?>
                            <option value="<?= $s['id'] ?>"
                                    data-tempo="<?= $s['tempo_base_min'] ?>"
                                    data-preco="<?= $s['preco'] ?>"
                                    data-preco-medio="<?= $s['preco_adicional_medio'] ?>"
                                    data-preco-grande="<?= $s['preco_adicional_grande'] ?>">
                                <?= htmlspecialchars($s['nome']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <!-- Resumo de duração e preço -->
                <div id="resumo-servico" class="resumo-box" style="display:none">
                    <div class="resumo-item">⏱ <span id="res-duracao">—</span></div>
                    <div class="resumo-item">💰 <span id="res-preco">—</span></div>
                </div>

                <div class="form-row">
                    <!-- Data -->
                    <div class="campo">
                        <label for="data">Data</label>
                        <input type="date" id="data" name="data" required
                               min="<?= date('Y-m-d') ?>">
                    </div>

                    <!-- Horário -->
                    <div class="campo campo-full">
                        <label>Horário disponível</label>
                        <div id="horarios-container">
                            <p class="hint">Selecione pet, serviço e data.</p>
                        </div>
                        <input type="hidden" id="horario" name="horario">
                    </div>
                </div>

                <hr class="divisor">

                <div class="form-row">
                    <!-- Pagamento -->
                    <div class="campo">
                        <label for="pagamento">Forma de pagamento</label>
                        <select id="pagamento" name="pagamento" required>
                            <option value="pix">💚 PIX</option>
                            <option value="dinheiro">💵 Dinheiro</option>
                            <option value="debito">💳 Cartão de Débito</option>
                            <option value="credito">💳 Cartão de Crédito</option>
                        </select>
                    </div>

                    <!-- Transporte -->
                    <div class="campo">
                        <label for="transporte">Transporte</label>
                        <select id="transporte" name="transporte" required>
                            <option value="proprio">🚗 Próprio (sem taxa)</option>
                            <option value="taxipet">🚕 TaxiPet (+R$ <?= number_format($taxaTaxiPet, 2, ',', '.') ?>)</option>
                        </select>
                    </div>
                </div>

                <!-- Total -->
                <div id="total-box" class="total-box" style="display:none">
                    <span>Total estimado:</span>
                    <strong id="total-valor">R$ 0,00</strong>
                </div>

                <button type="submit" class="btn btn-primary btn-block" id="btn-agendar" disabled>
                    Confirmar Agendamento
                </button>
            </form>

            <?php endif; ?>
        </section>

        <!-- ── Próximos agendamentos ──────────────────────────────────────── -->
        <section class="card">
            <h2 class="card-title">Meus Próximos Agendamentos</h2>

            <?php if ($msg && isset($msgMap[$msg])): ?>
            <div class="alert alert-<?= $msgMap[$msg]['tipo'] ?>">
                <?= $msgMap[$msg]['texto'] ?>
            </div>
            <?php endif; ?>

            <?php if (empty($proximosAgendamentos)): ?>
                <p class="hint">Nenhum agendamento futuro.</p>
            <?php else: ?>
            <div class="table-wrapper">
                <table class="tabela">
                    <thead>
                        <tr>
                            <th>Data</th>
                            <th>Início</th>
                            <th>Término</th>
                            <th>Pet</th>
                            <th>Serviço</th>
                            <th>Transporte</th>
                            <th>Pagamento</th>
                            <th>Total</th>
                            <th>Ação</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($proximosAgendamentos as $ag): ?>
                        <tr>
                            <td><?= date('d/m/Y', strtotime($ag['data_hora_inicio'])) ?></td>
                            <td><?= date('H:i',   strtotime($ag['data_hora_inicio'])) ?></td>
                            <td><?= date('H:i',   strtotime($ag['data_hora_fim']))    ?></td>
                            <td><?= htmlspecialchars($ag['pet_nome'])     ?></td>
                            <td><?= htmlspecialchars($ag['servico_nome']) ?></td>
                            <td><?= $transpLabel[$ag['transporte']] ?? '—' ?></td>
                            <td><?= $pagtoLabel[$ag['metodo_pagamento']] ?? '—' ?></td>
                            <td>R$ <?= number_format($ag['valor_total'], 2, ',', '.') ?></td>
                            <td>
                                <button type="button"
                                        class="btn btn-sm btn-danger"
                                        onclick="confirmarCancelamento(
                                            <?= $ag['id'] ?>,
                                            '<?= date('d/m/Y H:i', strtotime($ag['data_hora_inicio'])) ?>',
                                            '<?= htmlspecialchars(addslashes($ag['servico_nome'])) ?>'
                                        )">
                                    ✕ Desmarcar
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </section>

    </div>
</main>

<!-- Modal de confirmação de desmarcação -->
<div id="modal-desmarcar" class="modal" style="display:none" role="dialog" aria-modal="true">
    <div class="modal-overlay" onclick="fecharModal()"></div>
    <div class="modal-box">
        <h3>Desmarcar Agendamento</h3>
        <p id="modal-texto"></p>
        <div class="modal-acoes">
            <button type="button" class="btn btn-outline" onclick="fecharModal()">Não, voltar</button>
            <form id="form-desmarcar" method="POST" action="/petshop/cliente/desmarcar.php" style="display:inline">
                <input type="hidden" name="agendamento_id" id="modal-agendamento-id">
                <button type="submit" class="btn btn-danger">Sim, desmarcar</button>
            </form>
        </div>
    </div>
</div>

<script>
const TAXA_TAXIPET    = <?= json_encode($taxaTaxiPet) ?>;
const ADICIONAL_PORTE = { pequeno: 0, medio: 15, grande: 30 };

function confirmarCancelamento(id, data, servico) {
    document.getElementById('modal-texto').textContent =
        'Deseja desmarcar o agendamento de ' + servico + ' no dia ' + data + '?';
    document.getElementById('modal-agendamento-id').value = id;
    document.getElementById('modal-desmarcar').style.display = 'flex';
}

function fecharModal() {
    document.getElementById('modal-desmarcar').style.display = 'none';
}

document.addEventListener('keydown', e => { if (e.key === 'Escape') fecharModal(); });
</script>
<script src="/petshop/assets/js/agendar.js"></script>
</body>
</html>

