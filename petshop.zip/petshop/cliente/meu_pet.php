<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';

requireCliente();

$pdo  = getDB();
$erro = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome  = trim($_POST['nome']  ?? '');
    $raca  = trim($_POST['raca']  ?? '');
    $porte = $_POST['porte'] ?? '';
    $portesValidos = ['pequeno', 'medio', 'grande'];

    if (!$nome || !$raca || !in_array($porte, $portesValidos)) {
        $erro = 'Preencha todos os campos.';
    } else {
        $stmt = $pdo->prepare('INSERT INTO pets (usuario_id, nome, raca, porte) VALUES (?, ?, ?, ?)');
        $stmt->execute([$_SESSION['usuario_id'], $nome, $raca, $porte]);
        $sucesso = 'Pet adicionado com sucesso!';
    }
}

$stmt = $pdo->prepare('SELECT id, nome, raca, porte FROM pets WHERE usuario_id = ? ORDER BY nome');
$stmt->execute([$_SESSION['usuario_id']]);
$pets = $stmt->fetchAll();

$portesLabel = ['pequeno' => 'Pequeno', 'medio' => 'Médio', 'grande' => 'Grande'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meus Pets — Patinhas & Cia</title>
    <link rel="stylesheet" href="/petshop/assets/css/style.css">
</head>
<body class="app-page">

<header class="app-header">
    <div class="header-inner">
        <span class="logo-icon">🐾</span>
        <span class="header-title">Patinhas & Cia</span>
        <nav class="header-nav">
            <a href="/petshop/cliente/agendar.php" class="btn btn-outline btn-sm">← Agendar</a>
            <a href="/petshop/cliente/logout.php"  class="btn btn-outline btn-sm">Sair</a>
        </nav>
    </div>
</header>

<main class="app-main">
    <div class="container">

        <section class="card">
            <h2 class="card-title">Adicionar Pet</h2>

            <?php if ($erro):    ?><div class="alert alert-erro"><?= htmlspecialchars($erro) ?></div><?php endif; ?>
            <?php if ($sucesso): ?><div class="alert alert-sucesso"><?= htmlspecialchars($sucesso) ?></div><?php endif; ?>

            <form method="POST" novalidate>
                <div class="campo">
                    <label for="nome">Nome do pet</label>
                    <input type="text" id="nome" name="nome" required>
                </div>
                <div class="campo">
                    <label for="raca">Raça</label>
                    <input type="text" id="raca" name="raca" required>
                </div>
                <div class="campo">
                    <label for="porte">Porte</label>
                    <select id="porte" name="porte" required>
                        <option value="">Selecione…</option>
                        <option value="pequeno">Pequeno</option>
                        <option value="medio">Médio</option>
                        <option value="grande">Grande</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Adicionar</button>
            </form>
        </section>

        <section class="card">
            <h2 class="card-title">Meus Pets</h2>
            <?php if (empty($pets)): ?>
                <p class="hint">Nenhum pet cadastrado ainda.</p>
            <?php else: ?>
            <div class="table-wrapper">
                <table class="tabela">
                    <thead><tr><th>Nome</th><th>Raça</th><th>Porte</th></tr></thead>
                    <tbody>
                        <?php foreach ($pets as $p): ?>
                        <tr>
                            <td><?= htmlspecialchars($p['nome']) ?></td>
                            <td><?= htmlspecialchars($p['raca']) ?></td>
                            <td><?= $portesLabel[$p['porte']] ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </section>

    </div>
</main>
</body>
</html>

