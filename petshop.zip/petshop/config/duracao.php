<?php
/**
 * Regras de negócio: duração e preço dos serviços.
 */

const ADICIONAL_PORTE_MIN = [
    'pequeno' => 0,
    'medio'   => 15,
    'grande'  => 30,
];

function calcularDuracao(int $tempoBaseMin, string $porte): int
{
    return $tempoBaseMin + (ADICIONAL_PORTE_MIN[$porte] ?? 0);
}

function calcularPreco(float $precoBase, float $adicionalMedio, float $adicionalGrande, string $porte): float
{
    return match ($porte) {
        'medio'  => $precoBase + $adicionalMedio,
        'grande' => $precoBase + $adicionalGrande,
        default  => $precoBase,
    };
}

function getTaxaTaxiPet(\PDO $pdo): float
{
    $stmt = $pdo->prepare("SELECT valor FROM configuracoes WHERE chave = 'taxa_taxipet'");
    $stmt->execute();
    $row = $stmt->fetch();
    return $row ? (float)$row['valor'] : 25.00;
}

function getConfig(\PDO $pdo, string $chave, string $default = ''): string
{
    $stmt = $pdo->prepare("SELECT valor FROM configuracoes WHERE chave = ?");
    $stmt->execute([$chave]);
    $row = $stmt->fetch();
    return $row ? $row['valor'] : $default;
}

