<?php
/**
 * Inicializa a sessão com configurações seguras.
 * Inclua este arquivo no topo de toda página que precise de sessão.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => false,   // mude para true em HTTPS
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_start();
}

/**
 * Redireciona se o usuário não estiver logado como cliente.
 */
function requireCliente(): void
{
    if (empty($_SESSION['usuario_id']) || ($_SESSION['perfil'] ?? '') !== 'cliente') {
        header('Location: /petshop/cliente/login.php');
        exit;
    }
}

/**
 * Redireciona se o usuário não estiver logado como admin.
 */
function requireAdmin(): void
{
    if (empty($_SESSION['usuario_id']) || ($_SESSION['perfil'] ?? '') !== 'admin') {
        header('Location: /petshop/admin/login.php');
        exit;
    }
}

