-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 29/05/2026 às 21:47
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `petshop3b`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendamentos`
--

CREATE TABLE `agendamentos` (
  `id` int(10) UNSIGNED NOT NULL,
  `usuario_id` int(10) UNSIGNED NOT NULL,
  `pet_id` int(10) UNSIGNED NOT NULL,
  `servico_id` int(10) UNSIGNED NOT NULL,
  `data_hora_inicio` datetime NOT NULL,
  `data_hora_fim` datetime NOT NULL,
  `duracao_min` smallint(6) NOT NULL COMMENT 'Duração total calculada',
  `metodo_pagamento` enum('dinheiro','debito','credito','pix') NOT NULL DEFAULT 'pix',
  `transporte` enum('proprio','taxipet') NOT NULL DEFAULT 'proprio',
  `taxa_transporte` decimal(8,2) NOT NULL DEFAULT 0.00,
  `valor_servico` decimal(8,2) NOT NULL DEFAULT 0.00,
  `valor_total` decimal(8,2) NOT NULL DEFAULT 0.00,
  `status` enum('agendado','cancelado','concluido') NOT NULL DEFAULT 'agendado',
  `observacao` text DEFAULT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `agendamentos`
--

INSERT INTO `agendamentos` (`id`, `usuario_id`, `pet_id`, `servico_id`, `data_hora_inicio`, `data_hora_fim`, `duracao_min`, `metodo_pagamento`, `transporte`, `taxa_transporte`, `valor_servico`, `valor_total`, `status`, `observacao`, `criado_em`) VALUES
(1, 2, 1, 1, '2026-06-11 08:30:00', '2026-06-11 09:30:00', 60, 'pix', 'proprio', 0.00, 0.00, 0.00, 'cancelado', NULL, '2026-05-29 10:55:08'),
(2, 2, 2, 1, '2026-06-11 09:30:00', '2026-06-11 10:30:00', 60, 'debito', 'proprio', 0.00, 55.00, 55.00, 'agendado', NULL, '2026-05-29 11:37:54'),
(3, 2, 1, 1, '2026-06-11 10:30:00', '2026-06-11 11:30:00', 60, 'debito', 'proprio', 0.00, 55.00, 55.00, 'agendado', NULL, '2026-05-29 11:38:34'),
(4, 4, 3, 3, '2026-05-29 17:00:00', '2026-05-29 18:00:00', 60, 'credito', 'proprio', 0.00, 80.00, 80.00, 'agendado', NULL, '2026-05-29 11:42:51'),
(5, 4, 4, 2, '2026-06-05 08:30:00', '2026-06-05 09:10:00', 40, 'credito', 'proprio', 0.00, 50.00, 50.00, 'agendado', NULL, '2026-05-29 11:43:49'),
(6, 2, 2, 1, '2026-06-15 10:30:00', '2026-06-15 11:30:00', 60, 'dinheiro', 'taxipet', 25.00, 55.00, 80.00, 'agendado', NULL, '2026-05-29 16:22:12');

-- --------------------------------------------------------

--
-- Estrutura para tabela `configuracoes`
--

CREATE TABLE `configuracoes` (
  `chave` varchar(60) NOT NULL,
  `valor` varchar(255) NOT NULL,
  `descricao` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `configuracoes`
--

INSERT INTO `configuracoes` (`chave`, `valor`, `descricao`) VALUES
('descricao_loja', 'Cuidado e carinho para o seu melhor amigo!', 'Slogan'),
('endereco_loja', 'Rua Exemplo, 123 — Bairro, Cidade', 'Endereço da loja'),
('horario_abertura', '08:00', 'Horário de abertura'),
('horario_fechamento', '18:00', 'Horário de fechamento'),
('instagram_loja', '@patinhasecia', 'Instagram da loja'),
('intervalo_slot_min', '30', 'Intervalo entre slots (minutos)'),
('nome_loja', 'Patinhas & Cia', 'Nome da loja'),
('taxa_taxipet', '25.00', 'Taxa de transporte TaxiPet (R$)'),
('telefone_loja', '(11) 00000-0000', 'Telefone de contato');

-- --------------------------------------------------------

--
-- Estrutura para tabela `pets`
--

CREATE TABLE `pets` (
  `id` int(10) UNSIGNED NOT NULL,
  `usuario_id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(80) NOT NULL,
  `raca` varchar(80) NOT NULL,
  `porte` enum('pequeno','medio','grande') NOT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `pets`
--

INSERT INTO `pets` (`id`, `usuario_id`, `nome`, `raca`, `porte`, `criado_em`) VALUES
(1, 2, 'Dora', 'Pator Belga', 'grande', '2026-05-29 10:54:38'),
(2, 2, 'Bela', 'Pator Belga', 'grande', '2026-05-29 11:37:03'),
(3, 4, 'Amora', 'Golden Retriever', 'grande', '2026-05-29 11:40:55'),
(4, 4, 'Chloe', 'Shitzu', 'pequeno', '2026-05-29 11:40:55'),
(5, 5, 'Fred', 'Shitzu', 'pequeno', '2026-05-29 13:59:28');

-- --------------------------------------------------------

--
-- Estrutura para tabela `servicos`
--

CREATE TABLE `servicos` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(80) NOT NULL,
  `tempo_base_min` smallint(6) NOT NULL COMMENT 'Duração base em minutos',
  `preco` decimal(8,2) NOT NULL DEFAULT 0.00,
  `preco_adicional_medio` decimal(8,2) NOT NULL DEFAULT 0.00,
  `preco_adicional_grande` decimal(8,2) NOT NULL DEFAULT 0.00,
  `ativo` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `servicos`
--

INSERT INTO `servicos` (`id`, `nome`, `tempo_base_min`, `preco`, `preco_adicional_medio`, `preco_adicional_grande`, `ativo`) VALUES
(1, 'Banho', 30, 35.00, 10.00, 20.00, 1),
(2, 'Tosa', 40, 50.00, 15.00, 25.00, 1),
(3, 'Consulta', 30, 80.00, 0.00, 0.00, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(100) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `email` varchar(150) NOT NULL,
  `senha_hash` varchar(255) NOT NULL,
  `perfil` enum('cliente','admin') NOT NULL DEFAULT 'cliente',
  `criado_em` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `telefone`, `email`, `senha_hash`, `perfil`, `criado_em`) VALUES
(2, 'marta helena', '11978781232', 'marta.h.souza@aluno.senai.br', '$2y$12$m3bdI7AmEO/0G62PJG1Gmejt6OtM1BTQdZdxzEvu0cubJZwkoNv9O', 'cliente', '2026-05-29 10:54:38'),
(3, 'Administrador', '(00) 00000-0000', 'admin@patinhasecia.com', '$2y$10$XcBl6Mmx7C9cwJQNZtlCxeuHFD2tUr2Z6zxn.CF8ooJgHPX.quJ6C', 'admin', '2026-05-29 10:57:30'),
(4, 'Laura Sousa', '11991490321', 'laurasousa@gmail.com', '$2y$12$Qyy9QJ0Cg7GygvQFW7Al3.bTgoUOqr8zBGgJ0cTD3QGfVAtaADwQO', 'cliente', '2026-05-29 11:40:55'),
(5, 'Marcelo', '1111111111', 'marcelo@gmail.com', '$2y$12$Jm4SoG0xwXTyzR/hXqIxJOrngNDOk15l100vLr3OxbZ9dcSDl4j0a', 'cliente', '2026-05-29 13:59:28');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `agendamentos`
--
ALTER TABLE `agendamentos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_agend_usuario` (`usuario_id`),
  ADD KEY `fk_agend_pet` (`pet_id`),
  ADD KEY `fk_agend_servico` (`servico_id`),
  ADD KEY `idx_data_status` (`data_hora_inicio`,`status`);

--
-- Índices de tabela `configuracoes`
--
ALTER TABLE `configuracoes`
  ADD PRIMARY KEY (`chave`);

--
-- Índices de tabela `pets`
--
ALTER TABLE `pets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pets_usuario` (`usuario_id`);

--
-- Índices de tabela `servicos`
--
ALTER TABLE `servicos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `agendamentos`
--
ALTER TABLE `agendamentos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `pets`
--
ALTER TABLE `pets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `servicos`
--
ALTER TABLE `servicos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `agendamentos`
--
ALTER TABLE `agendamentos`
  ADD CONSTRAINT `fk_agend_pet` FOREIGN KEY (`pet_id`) REFERENCES `pets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_agend_servico` FOREIGN KEY (`servico_id`) REFERENCES `servicos` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_agend_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para tabelas `pets`
--
ALTER TABLE `pets`
  ADD CONSTRAINT `fk_pets_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
