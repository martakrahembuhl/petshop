<?php
/**
 * Script de diagnóstico — apague após usar.
 * Acesse: http://localhost/petshop/api/testar.php
 */
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/duracao.php';

header('Content-Type: text/html; charset=utf-8');

echo '<h2>Diagnóstico do Sistema</h2>';

// 1. Sessão
echo '<h3>1. Sessão</h3>';
echo 'usuario_id: ' . ($_SESSION['usuario_id'] ?? '<b style="color:red">NÃO LOGADO</b>') . '<br>';
echo 'perfil: '     . ($_SESSION['perfil']     ?? '—') . '<br>';
echo 'nome: '       . ($_SESSION['nome']       ?? '—') . '<br>';

// 2. Banco
echo '<h3>2. Banco de dados</h3>';
try {
    $pdo = getDB();
    echo '<span style="color:green">✓ Conectado</span><br>';

    // Serviços
    $servicos = $pdo->query('SELECT id, nome, tempo_base_min, preco FROM servicos WHERE ativo = 1')->fetchAll();
    echo '<br><b>Serviços:</b><br>';
    foreach ($servicos as $s) {
        echo "ID {$s['id']}: {$s['nome']} — {$s['tempo_base_min']}min — R$ {$s['preco']}<br>";
    }

    // Colunas da tabela agendamentos
    $cols = $pdo->query("SHOW COLUMNS FROM agendamentos")->fetchAll();
    echo '<br><b>Colunas de agendamentos:</b><br>';
    foreach ($cols as $c) {
        echo "• {$c['Field']} ({$c['Type']})<br>";
    }

    // Configurações
    $cfgs = $pdo->query("SELECT chave, valor FROM configuracoes")->fetchAll();
    echo '<br><b>Configurações:</b><br>';
    foreach ($cfgs as $c) {
        echo "• {$c['chave']}: {$c['valor']}<br>";
    }

} catch (Exception $e) {
    echo '<span style="color:red">✗ Erro: ' . $e->getMessage() . '</span><br>';
}

// 3. Teste de horários
echo '<h3>3. Teste de horários disponíveis</h3>';
$url = 'http://localhost/petshop/api/horarios_disponiveis.php?data=' . date('Y-m-d') . '&servico_id=1&porte=pequeno';
echo "URL: <a href='$url' target='_blank'>$url</a><br>";

echo '<br><p style="color:red"><b>Apague este arquivo após o diagnóstico!</b></p>';
