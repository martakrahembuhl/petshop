<?php
/**
 * API: Cria um novo agendamento.
 *
 * POST /api/agendamento.php
 * Body JSON: { pet_id, servico_id, data, horario, pagamento, transporte }
 */

require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/duracao.php';

header('Content-Type: application/json; charset=utf-8');

requireCliente();

$body = json_decode(file_get_contents('php://input'), true);

$petId      = (int)($body['pet_id']     ?? 0);
$servicoId  = (int)($body['servico_id'] ?? 0);
$data       = $body['data']       ?? '';
$horario    = $body['horario']    ?? '';
$pagamento  = $body['pagamento']  ?? 'pix';
$transporte = $body['transporte'] ?? 'proprio';

$pagamentosValidos  = ['dinheiro', 'debito', 'credito', 'pix'];
$transportesValidos = ['proprio', 'taxipet'];

// ── Validações ────────────────────────────────────────────────────────────────
if ($petId <= 0 || $servicoId <= 0
    || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)
    || !preg_match('/^\d{2}:\d{2}$/', $horario)
    || !in_array($pagamento,  $pagamentosValidos)
    || !in_array($transporte, $transportesValidos)
) {
    http_response_code(400);
    echo json_encode(['erro' => 'Dados incompletos ou inválidos.']);
    exit;
}

$pdo = getDB();

// Confirma que o pet pertence ao cliente logado
$stmt = $pdo->prepare('SELECT id, porte FROM pets WHERE id = ? AND usuario_id = ?');
$stmt->execute([$petId, $_SESSION['usuario_id']]);
$pet = $stmt->fetch();

if (!$pet) {
    http_response_code(403);
    echo json_encode(['erro' => 'Pet não encontrado ou não pertence a você.']);
    exit;
}

// Busca serviço com preços
$stmt = $pdo->prepare(
    'SELECT tempo_base_min, preco, preco_adicional_medio, preco_adicional_grande
     FROM servicos WHERE id = ? AND ativo = 1'
);
$stmt->execute([$servicoId]);
$servico = $stmt->fetch();

if (!$servico) {
    http_response_code(404);
    echo json_encode(['erro' => 'Serviço não encontrado.']);
    exit;
}

// ── Cálculos ──────────────────────────────────────────────────────────────────
$duracaoMin   = calcularDuracao((int)$servico['tempo_base_min'], $pet['porte']);
$valorServico = calcularPreco(
    (float)$servico['preco'],
    (float)$servico['preco_adicional_medio'],
    (float)$servico['preco_adicional_grande'],
    $pet['porte']
);
$taxaTransporte = ($transporte === 'taxipet') ? getTaxaTaxiPet($pdo) : 0.00;
$valorTotal     = $valorServico + $taxaTransporte;

$inicio = new DateTime("{$data} {$horario}:00");
$fim    = clone $inicio;
$fim->modify("+{$duracaoMin} minutes");

// Bloqueia apenas se o horário de início já passou
// Usa margem de 1 minuto para evitar rejeição por diferença de segundos
$agora = new DateTime();
$agora->modify('-1 minute');
if ($inicio < $agora) {
    http_response_code(400);
    echo json_encode(['erro' => 'Este horário já passou. Escolha um horário futuro.']);
    exit;
}

// ── Verificação de conflito ───────────────────────────────────────────────────
$stmt = $pdo->prepare(
    "SELECT COUNT(*) FROM agendamentos
     WHERE status = 'agendado'
       AND data_hora_inicio < :fim
       AND data_hora_fim    > :inicio"
);
$stmt->execute([
    ':inicio' => $inicio->format('Y-m-d H:i:s'),
    ':fim'    => $fim->format('Y-m-d H:i:s'),
]);

if ((int)$stmt->fetchColumn() > 0) {
    http_response_code(409);
    echo json_encode(['erro' => 'Horário não disponível. Por favor, escolha outro.']);
    exit;
}

// ── Insere o agendamento ──────────────────────────────────────────────────────
$stmt = $pdo->prepare(
    "INSERT INTO agendamentos
        (usuario_id, pet_id, servico_id, data_hora_inicio, data_hora_fim,
         duracao_min, metodo_pagamento, transporte, taxa_transporte, valor_servico, valor_total)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
);
$stmt->execute([
    $_SESSION['usuario_id'],
    $petId,
    $servicoId,
    $inicio->format('Y-m-d H:i:s'),
    $fim->format('Y-m-d H:i:s'),
    $duracaoMin,
    $pagamento,
    $transporte,
    $taxaTransporte,
    $valorServico,
    $valorTotal,
]);

echo json_encode([
    'sucesso'     => true,
    'mensagem'    => 'Agendamento realizado com sucesso!',
    'inicio'      => $inicio->format('d/m/Y H:i'),
    'fim'         => $fim->format('H:i'),
    'duracao_min' => $duracaoMin,
    'valor_total' => 'R$ ' . number_format($valorTotal, 2, ',', '.'),
]);

