<?php
/**
 * API: Retorna os horários disponíveis para uma data, serviço e porte.
 *
 * GET /api/horarios_disponiveis.php
 *   ?data=YYYY-MM-DD
 *   &servico_id=1
 *   &porte=medio
 *   [&agendamento_id=5]   ← opcional: ignora o próprio agendamento ao remarcar
 *
 * Resposta JSON:
 *   { "duracao_min": 55, "horarios": ["08:00","08:30", ...] }
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/duracao.php';

header('Content-Type: application/json; charset=utf-8');

// ── Validação de entrada ──────────────────────────────────────────────────────
$data       = $_GET['data']       ?? '';
$servicoId  = (int)($_GET['servico_id'] ?? 0);
$porte      = $_GET['porte']      ?? '';
$ignorarId  = (int)($_GET['agendamento_id'] ?? 0);

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data) || $servicoId <= 0 || !array_key_exists($porte, ADICIONAL_PORTE_MIN)) {
    http_response_code(400);
    echo json_encode(['erro' => 'Parâmetros inválidos.']);
    exit;
}

$dataObj = DateTime::createFromFormat('Y-m-d', $data);
if (!$dataObj || $dataObj->format('Y-m-d') !== $data) {
    http_response_code(400);
    echo json_encode(['erro' => 'Data inválida.']);
    exit;
}

// Não permite datas no passado
$hoje = new DateTime('today');
if ($dataObj < $hoje) {
    echo json_encode(['duracao_min' => 0, 'horarios' => []]);
    exit;
}

// ── Busca tempo base do serviço ───────────────────────────────────────────────
$pdo  = getDB();
$stmt = $pdo->prepare('SELECT tempo_base_min FROM servicos WHERE id = ? AND ativo = 1');
$stmt->execute([$servicoId]);
$servico = $stmt->fetch();

if (!$servico) {
    http_response_code(404);
    echo json_encode(['erro' => 'Serviço não encontrado.']);
    exit;
}

$duracaoMin = calcularDuracao((int)$servico['tempo_base_min'], $porte);

// ── Busca agendamentos existentes no dia ──────────────────────────────────────
$sql = "SELECT data_hora_inicio, data_hora_fim
        FROM agendamentos
        WHERE DATE(data_hora_inicio) = :data
          AND status = 'agendado'";

$params = [':data' => $data];

if ($ignorarId > 0) {
    $sql .= ' AND id != :ignorar';
    $params[':ignorar'] = $ignorarId;
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$ocupados = $stmt->fetchAll();

// ── Gera slots de 30 em 30 minutos entre abertura e fechamento ───────────────
$horarioAbertura   = new DateTime("{$data} 08:00:00");
$horarioFechamento = new DateTime("{$data} 18:00:00");
$agora             = new DateTime();
$intervalo         = new DateInterval('PT30M');

$horariosLivres = [];
$cursor = clone $horarioAbertura;

while ($cursor < $horarioFechamento) {
    $fimSlot = clone $cursor;
    $fimSlot->modify("+{$duracaoMin} minutes");

    // Não oferece slot se o serviço ultrapassar o horário de fechamento
    if ($fimSlot > $horarioFechamento) {
        $cursor->add($intervalo);
        continue;
    }

    // Para hoje: não mostra slots que já passaram (compara início do slot com agora)
    if ($data === date('Y-m-d') && $cursor <= $agora) {
        $cursor->add($intervalo);
        continue;
    }

    // Verifica conflito com agendamentos existentes
    $conflito = false;
    foreach ($ocupados as $ag) {
        $inicio = new DateTime($ag['data_hora_inicio']);
        $fim    = new DateTime($ag['data_hora_fim']);

        if ($cursor < $fim && $fimSlot > $inicio) {
            $conflito = true;
            break;
        }
    }

    if (!$conflito) {
        $horariosLivres[] = $cursor->format('H:i');
    }

    $cursor->add($intervalo);
}

echo json_encode([
    'duracao_min' => $duracaoMin,
    'horarios'    => $horariosLivres,
]);

