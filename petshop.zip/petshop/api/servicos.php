<?php
/**
 * API: Retorna lista de serviços ativos.
 * GET /api/servicos.php
 */

require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json; charset=utf-8');

$pdo      = getDB();
$stmt     = $pdo->query('SELECT id, nome, tempo_base_min FROM servicos WHERE ativo = 1 ORDER BY nome');
$servicos = $stmt->fetchAll();

echo json_encode($servicos);

