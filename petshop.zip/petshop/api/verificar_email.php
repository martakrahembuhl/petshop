<?php
/**
 * API: Verifica se um e-mail já está cadastrado (usado no cadastro em tempo real).
 * GET /api/verificar_email.php?email=...
 */

require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json; charset=utf-8');

$email = trim($_GET['email'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['existe' => false]);
    exit;
}

$pdo  = getDB();
$stmt = $pdo->prepare('SELECT COUNT(*) FROM usuarios WHERE email = ?');
$stmt->execute([$email]);

echo json_encode(['existe' => (int)$stmt->fetchColumn() > 0]);

