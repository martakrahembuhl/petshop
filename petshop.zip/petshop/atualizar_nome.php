<?php
/**
 * Atualiza o nome da loja no banco de dados.
 * APAGUE este arquivo após usar!
 */
require_once __DIR__ . '/config/database.php';

$pdo = getDB();

$pdo->prepare("UPDATE configuracoes SET valor = 'Patinhas & Cia' WHERE chave = 'nome_loja'")->execute();
$pdo->prepare("UPDATE configuracoes SET valor = '@patinhasecia'  WHERE chave = 'instagram_loja'")->execute();
$pdo->prepare("UPDATE configuracoes SET valor = 'admin@patinhasecia.com' WHERE chave = 'email_loja'")->execute();

// Atualiza também o e-mail do admin se existir
$pdo->prepare("UPDATE usuarios SET email = 'admin@patinhasecia.com' WHERE email = 'admin@petshop3b.com'")->execute();

echo "<h2>✅ Nome atualizado no banco!</h2>";
echo "<p>Nome da loja: <strong>Patinhas & Cia</strong></p>";
echo "<p>Login admin: <strong>admin@patinhasecia.com</strong></p>";
echo "<p>Senha: <strong>admin123</strong></p>";
echo "<br><p style='color:red'><strong>⚠️ APAGUE este arquivo agora!</strong></p>";
echo "<p><a href='/petshop/'>Ver o site →</a></p>";
